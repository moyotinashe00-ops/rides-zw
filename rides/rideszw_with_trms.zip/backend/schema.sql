-- RidesZW Database Schema
-- Run this file once against your MySQL server:
--   mysql -u root -p < schema.sql

CREATE DATABASE IF NOT EXISTS rideszw CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE rideszw;

-- ─── Admin users ────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS admins (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(100) NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ─── Routes ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS routes (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  origin           VARCHAR(80)    NOT NULL,
  destination      VARCHAR(80)    NOT NULL,
  passenger_price  DECIMAL(10,2)  NOT NULL,   -- USD per seat
  cargo_price_sm   DECIMAL(10,2)  NOT NULL,   -- small parcel
  cargo_price_md   DECIMAL(10,2)  NOT NULL,   -- medium
  cargo_price_lg   DECIMAL(10,2)  NOT NULL,   -- large / sack / box
  distance_km      INT            NOT NULL,
  duration_hrs     DECIMAL(4,1)   NOT NULL,
  active           BOOL           DEFAULT TRUE,
  created_at       DATETIME       DEFAULT CURRENT_TIMESTAMP
);

-- ─── Bookings ────────────────────────────────────────────────────────────────
-- One table covers both passenger and cargo bookings.
-- booking_type determines which group of columns is populated.
CREATE TABLE IF NOT EXISTS bookings (
  id               INT AUTO_INCREMENT PRIMARY KEY,
  ref              VARCHAR(20)   NOT NULL UNIQUE,   -- e.g. MT00042
  booking_type     ENUM('passenger','cargo') NOT NULL DEFAULT 'passenger',
  route_id         INT           NOT NULL,
  travel_date      DATE          NOT NULL,
  travel_time      TIME          NOT NULL,
  pickup_address   VARCHAR(255),
  pickup_lat       DECIMAL(10,7),
  pickup_lng       DECIMAL(10,7),
  dropoff_address  VARCHAR(255),
  dropoff_lat      DECIMAL(10,7),
  dropoff_lng      DECIMAL(10,7),
  amount           DECIMAL(10,2) NOT NULL,
  payment_method   ENUM('ecocash','onemoney','whatsapp_pay','cash') DEFAULT 'ecocash',
  status           ENUM('pending','confirmed','in_transit','completed','cancelled') DEFAULT 'pending',
  created_at       DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at       DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,

  -- ── Passenger-only fields ──────────────────────────────────────────────
  passenger_name   VARCHAR(120),
  passenger_phone  VARCHAR(20),
  seats            TINYINT DEFAULT 1,

  -- ── Cargo-only fields ─────────────────────────────────────────────────
  sender_name      VARCHAR(120),
  sender_phone     VARCHAR(20),
  receiver_name    VARCHAR(120),
  receiver_phone   VARCHAR(20),
  cargo_description VARCHAR(255),
  cargo_size       ENUM('small','medium','large'),   -- drives cargo_price_*
  cargo_weight_kg  DECIMAL(6,2),                    -- optional, informational

  FOREIGN KEY (route_id) REFERENCES routes(id)
);

-- ─── Seed: routes ────────────────────────────────────────────────────────────
INSERT INTO routes
  (origin, destination, passenger_price, cargo_price_sm, cargo_price_md, cargo_price_lg, distance_km, duration_hrs)
VALUES
  ('Harare',   'Masvingo',     15.00,  5.00,  8.00, 12.00, 292, 3.5),
  ('Masvingo', 'Harare',       15.00,  5.00,  8.00, 12.00, 292, 3.5),
  ('Harare',   'Bulawayo',     25.00,  8.00, 12.00, 18.00, 439, 5.0),
  ('Bulawayo', 'Harare',       25.00,  8.00, 12.00, 18.00, 439, 5.0),
  ('Harare',   'Mutare',       18.00,  6.00,  9.00, 14.00, 263, 3.0),
  ('Mutare',   'Harare',       18.00,  6.00,  9.00, 14.00, 263, 3.0),
  ('Harare',   'Gweru',        12.00,  4.00,  7.00, 10.00, 275, 3.0),
  ('Gweru',    'Harare',       12.00,  4.00,  7.00, 10.00, 275, 3.0),
  ('Harare',   'Beitbridge',   30.00, 10.00, 15.00, 22.00, 582, 6.5),
  ('Bulawayo', 'Beitbridge',   18.00,  6.00,  9.00, 14.00, 323, 3.5);

-- ─── Seed: default admin ─────────────────────────────────────────────────────
-- Password is "admin123" — CHANGE THIS after first login.
INSERT INTO admins (name, email, password_hash) VALUES (
  'RidesZW Admin',
  'admin@rideszw.co.zw',
  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHG'
);

-- ═══════════════════════════════════════════════════════════════════
--  TRUCK DRIVE LOADBOARD EXTENSION
-- ═══════════════════════════════════════════════════════════════════

-- ─── Truck owners / drivers ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS truck_owners (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  phone         VARCHAR(20)  NOT NULL UNIQUE,
  email         VARCHAR(120),
  password_hash VARCHAR(255) NOT NULL,
  company_name  VARCHAR(120),
  verified      BOOL         DEFAULT FALSE,
  rating        DECIMAL(3,2) DEFAULT 0.00,
  trips_done    INT          DEFAULT 0,
  created_at    DATETIME     DEFAULT CURRENT_TIMESTAMP
);

-- ─── Trucks registered by owners ─────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS trucks (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  owner_id            INT          NOT NULL,
  registration        VARCHAR(20)  NOT NULL UNIQUE,
  truck_class         ENUM('pickup','1_3ton','5ton','10ton','flatbed','tanker','refrigerated') NOT NULL,
  max_payload_kg      DECIMAL(8,2) NOT NULL,
  make_model          VARCHAR(100),
  year                YEAR,
  status              ENUM('available','on_job','inactive') DEFAULT 'available',
  current_location    VARCHAR(150),
  created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (owner_id) REFERENCES truck_owners(id)
);

-- ─── Load listings posted by shippers ────────────────────────────────────────
CREATE TABLE IF NOT EXISTS loads (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  ref                 VARCHAR(20)   NOT NULL UNIQUE,
  -- poster info (no account needed — shippers just fill a form)
  poster_name         VARCHAR(120)  NOT NULL,
  poster_phone        VARCHAR(20)   NOT NULL,
  poster_email        VARCHAR(120),
  -- route
  origin              VARCHAR(120)  NOT NULL,
  destination         VARCHAR(120)  NOT NULL,
  pickup_lat          DECIMAL(10,7),
  pickup_lng          DECIMAL(10,7),
  dropoff_lat         DECIMAL(10,7),
  dropoff_lng         DECIMAL(10,7),
  -- cargo
  cargo_description   VARCHAR(255)  NOT NULL,
  cargo_weight_kg     DECIMAL(8,2),
  cargo_type          ENUM('general','perishable','hazmat','livestock','machinery','furniture','other') DEFAULT 'general',
  required_truck_class ENUM('any','pickup','1_3ton','5ton','10ton','flatbed','tanker','refrigerated') DEFAULT 'any',
  -- scheduling
  pickup_date         DATE          NOT NULL,
  pickup_window       VARCHAR(60),         -- e.g. "08:00 - 12:00"
  -- payment
  offered_rate        DECIMAL(10,2),       -- NULL = negotiable
  currency            VARCHAR(3)    DEFAULT 'USD',
  rate_negotiable     BOOL          DEFAULT TRUE,
  payment_method      ENUM('ecocash','onemoney','cash','bank') DEFAULT 'ecocash',
  -- status lifecycle
  status              ENUM('open','assigned','in_transit','delivered','expired','cancelled') DEFAULT 'open',
  assigned_truck_id   INT,
  assigned_owner_id   INT,
  -- timestamps
  expires_at          DATETIME,
  created_at          DATETIME      DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME      DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (assigned_truck_id)  REFERENCES trucks(id),
  FOREIGN KEY (assigned_owner_id)  REFERENCES truck_owners(id)
);

-- ─── Bids: truck owners bid on open loads ────────────────────────────────────
CREATE TABLE IF NOT EXISTS load_bids (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  load_id       INT           NOT NULL,
  owner_id      INT           NOT NULL,
  truck_id      INT           NOT NULL,
  bid_amount    DECIMAL(10,2) NOT NULL,
  note          TEXT,
  status        ENUM('pending','accepted','rejected','withdrawn') DEFAULT 'pending',
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (load_id)    REFERENCES loads(id),
  FOREIGN KEY (owner_id)   REFERENCES truck_owners(id),
  FOREIGN KEY (truck_id)   REFERENCES trucks(id)
);

-- ─── Seed: demo truck owner ───────────────────────────────────────────────────
-- Password is "driver123"
INSERT INTO truck_owners (name, phone, email, password_hash, company_name, verified) VALUES (
  'Demo Driver',
  '+263771000001',
  'driver@rideszw.co.zw',
  '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHG',
  'Demo Haulage',
  TRUE
);

INSERT INTO trucks (owner_id, registration, truck_class, max_payload_kg, make_model, year) VALUES
  (1, 'ABD 1234', '5ton',   5000,  'Isuzu NQR',     2019),
  (1, 'ACX 5678', '10ton',  10000, 'Hino 700',      2020);
