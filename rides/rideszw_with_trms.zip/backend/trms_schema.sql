-- ═══════════════════════════════════════════════════════════════════
--  TRMS EXTENSION — Truck Request Management System
--  Run this file separately after the main schema.sql
--  mysql -u root -p rideszw < backend/trms_schema.sql
-- ═══════════════════════════════════════════════════════════════════

USE rideszw;

-- ─── TRMS Users (requesters, supervisors, transport managers) ────────────────
CREATE TABLE IF NOT EXISTS trms_users (
  id            INT AUTO_INCREMENT PRIMARY KEY,
  name          VARCHAR(120) NOT NULL,
  email         VARCHAR(120) NOT NULL UNIQUE,
  phone         VARCHAR(20),
  password_hash VARCHAR(255) NOT NULL,
  role          ENUM('requester','supervisor','transport_manager','admin') NOT NULL DEFAULT 'requester',
  department    VARCHAR(100),
  active        BOOL DEFAULT TRUE,
  created_at    DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ─── Fleet / Trucks ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fleet (
  id                INT AUTO_INCREMENT PRIMARY KEY,
  registration      VARCHAR(20)  NOT NULL UNIQUE,
  make_model        VARCHAR(100) NOT NULL,
  year              YEAR,
  truck_class       ENUM('pickup','1_3ton','5ton','10ton','flatbed','tanker','refrigerated') NOT NULL,
  max_payload_kg    DECIMAL(8,2),
  status            ENUM('available','assigned','maintenance','inactive') DEFAULT 'available',
  current_location  VARCHAR(150),
  last_service_date DATE,
  next_service_date DATE,
  notes             TEXT,
  created_at        DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at        DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- ─── Drivers ─────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS drivers (
  id              INT AUTO_INCREMENT PRIMARY KEY,
  name            VARCHAR(120) NOT NULL,
  phone           VARCHAR(20)  NOT NULL UNIQUE,
  email           VARCHAR(120),
  license_number  VARCHAR(40)  NOT NULL UNIQUE,
  license_expiry  DATE         NOT NULL,
  status          ENUM('available','on_trip','off_duty','suspended') DEFAULT 'available',
  rating          DECIMAL(3,2) DEFAULT 0.00,
  trips_completed INT          DEFAULT 0,
  notes           TEXT,
  created_at      DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ─── Truck Requests ──────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS truck_requests (
  id                  INT AUTO_INCREMENT PRIMARY KEY,
  ref                 VARCHAR(20)   NOT NULL UNIQUE,
  requester_id        INT           NOT NULL,
  -- trip details
  purpose             VARCHAR(255)  NOT NULL,
  origin              VARCHAR(150)  NOT NULL,
  destination         VARCHAR(150)  NOT NULL,
  pickup_lat          DECIMAL(10,7),
  pickup_lng          DECIMAL(10,7),
  dropoff_lat         DECIMAL(10,7),
  dropoff_lng         DECIMAL(10,7),
  cargo_description   VARCHAR(255),
  cargo_weight_kg     DECIMAL(8,2),
  required_truck_class ENUM('any','pickup','1_3ton','5ton','10ton','flatbed','tanker','refrigerated') DEFAULT 'any',
  -- scheduling
  requested_date      DATE          NOT NULL,
  requested_time      TIME          NOT NULL,
  return_required     BOOL          DEFAULT FALSE,
  return_date         DATE,
  -- approval workflow
  status              ENUM('pending','supervisor_approved','manager_approved','assigned','in_transit','completed','rejected','cancelled') DEFAULT 'pending',
  supervisor_id       INT,
  supervisor_approved_at DATETIME,
  supervisor_comment  TEXT,
  manager_id          INT,
  manager_approved_at DATETIME,
  manager_comment     TEXT,
  rejection_reason    TEXT,
  -- assignment
  assigned_fleet_id   INT,
  assigned_driver_id  INT,
  assigned_at         DATETIME,
  -- completion
  actual_start        DATETIME,
  actual_end          DATETIME,
  distance_km         DECIMAL(8,2),
  requester_rating    TINYINT,        -- 1-5
  requester_feedback  TEXT,
  -- timestamps
  created_at          DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at          DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (requester_id)      REFERENCES trms_users(id),
  FOREIGN KEY (supervisor_id)     REFERENCES trms_users(id),
  FOREIGN KEY (manager_id)        REFERENCES trms_users(id),
  FOREIGN KEY (assigned_fleet_id) REFERENCES fleet(id),
  FOREIGN KEY (assigned_driver_id) REFERENCES drivers(id)
);

-- ─── Approval notifications ───────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS trms_notifications (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  user_id     INT          NOT NULL,
  request_id  INT          NOT NULL,
  type        ENUM('submitted','supervisor_approved','manager_approved','assigned','rejected','completed','cancelled') NOT NULL,
  message     TEXT         NOT NULL,
  read_at     DATETIME,
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id)    REFERENCES trms_users(id),
  FOREIGN KEY (request_id) REFERENCES truck_requests(id)
);

-- ─── Fleet maintenance history ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS fleet_maintenance (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  fleet_id    INT          NOT NULL,
  type        ENUM('service','repair','inspection','tyre','other') NOT NULL,
  description TEXT,
  cost        DECIMAL(10,2),
  date        DATE         NOT NULL,
  next_due    DATE,
  done_by     VARCHAR(120),
  created_at  DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (fleet_id) REFERENCES fleet(id)
);

-- ─── Driver trip history ──────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS driver_trips (
  id          INT AUTO_INCREMENT PRIMARY KEY,
  driver_id   INT NOT NULL,
  request_id  INT NOT NULL,
  fleet_id    INT NOT NULL,
  started_at  DATETIME,
  ended_at    DATETIME,
  distance_km DECIMAL(8,2),
  rating      TINYINT,
  feedback    TEXT,
  FOREIGN KEY (driver_id)  REFERENCES drivers(id),
  FOREIGN KEY (request_id) REFERENCES truck_requests(id),
  FOREIGN KEY (fleet_id)   REFERENCES fleet(id)
);

-- ─── Seeds ───────────────────────────────────────────────────────────────────
-- Default TRMS users (all passwords = "trms123")
INSERT IGNORE INTO trms_users (name, email, phone, password_hash, role, department) VALUES
  ('John Requester',      'requester@rideszw.co.zw',  '+263771000010', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHG', 'requester',         'Operations'),
  ('Sarah Supervisor',    'supervisor@rideszw.co.zw', '+263771000011', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHG', 'supervisor',         'Logistics'),
  ('Mike Manager',        'manager@rideszw.co.zw',    '+263771000012', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHG', 'transport_manager',  'Transport'),
  ('Admin TRMS',          'trmsadmin@rideszw.co.zw',  '+263771000013', '$2a$10$N9qo8uLOickgx2ZMRZoMyeIjZAgcfl7p92ldGxad68LJZdL17lHHG', 'admin',              'Admin');

-- Demo fleet
INSERT IGNORE INTO fleet (registration, make_model, year, truck_class, max_payload_kg, status, current_location) VALUES
  ('AAB 1111', 'Isuzu NQR 500',   2020, '5ton',   5000,  'available', 'Harare Depot'),
  ('AAB 2222', 'Hino 700 Series', 2019, '10ton',  10000, 'available', 'Harare Depot'),
  ('AAB 3333', 'Toyota Hilux',    2022, 'pickup',  1000,  'available', 'Bulawayo Depot'),
  ('AAB 4444', 'Mercedes Actros', 2021, 'flatbed', 15000, 'maintenance','Harare Workshop');

-- Demo drivers
INSERT IGNORE INTO drivers (name, phone, email, license_number, license_expiry, status) VALUES
  ('Charles Moyo',   '+263772000001', 'charles@rideszw.co.zw', 'ZW-DL-001234', '2027-06-30', 'available'),
  ('Tapiwa Dube',    '+263772000002', 'tapiwa@rideszw.co.zw',  'ZW-DL-005678', '2026-12-31', 'available'),
  ('Rutendo Chima',  '+263772000003', 'rutendo@rideszw.co.zw', 'ZW-DL-009012', '2028-03-15', 'available');
