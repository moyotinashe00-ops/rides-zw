const express = require('express');
const router  = express.Router();
const bcrypt  = require('bcryptjs');
const jwt     = require('jsonwebtoken');
const db      = require('../db');

// ── TRMS JWT middleware ───────────────────────────────────────────────────────
function trmsAuth(roles = []) {
  return (req, res, next) => {
    const header = req.headers['authorization'] || '';
    const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
    if (!token) return res.status(401).json({ error: 'No token' });
    try {
      const user = jwt.verify(token, process.env.JWT_SECRET);
      if (roles.length && !roles.includes(user.role))
        return res.status(403).json({ error: `Requires role: ${roles.join(' or ')}` });
      req.trmsUser = user;
      next();
    } catch {
      res.status(401).json({ error: 'Invalid or expired token' });
    }
  };
}

// POST /api/trms/auth/login
router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email and password required' });
  try {
    const [rows] = await db.query('SELECT * FROM trms_users WHERE email = ? AND active = 1', [email]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });
    const user = rows[0];
    const match = await bcrypt.compare(password, user.password_hash);
    if (!match) return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign(
      { id: user.id, name: user.name, email: user.email, role: user.role, department: user.department },
      process.env.JWT_SECRET,
      { expiresIn: '8h' }
    );
    res.json({ token, id: user.id, name: user.name, role: user.role, department: user.department });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/trms/auth/me
router.get('/me', trmsAuth(), (req, res) => res.json(req.trmsUser));

// GET /api/trms/auth/users — admin only
router.get('/users', trmsAuth(['admin']), async (req, res) => {
  const [rows] = await db.query('SELECT id, name, email, phone, role, department, active, created_at FROM trms_users ORDER BY role, name');
  res.json(rows);
});

// POST /api/trms/auth/users — admin creates users
router.post('/users', trmsAuth(['admin']), async (req, res) => {
  const { name, email, phone, password, role, department } = req.body;
  if (!name || !email || !password || !role) return res.status(400).json({ error: 'name, email, password, role required' });
  try {
    const hash = await bcrypt.hash(password, 10);
    await db.query('INSERT INTO trms_users (name, email, phone, password_hash, role, department) VALUES (?,?,?,?,?,?)',
      [name, email, phone||null, hash, role, department||null]);
    res.status(201).json({ message: 'User created' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Email already exists' });
    res.status(500).json({ error: e.message });
  }
});

module.exports = { router, trmsAuth };
