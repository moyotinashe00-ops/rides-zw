const express = require('express');
const router  = express.Router();
const db      = require('../db');
const auth    = require('../middleware/auth');
const { generateRef } = require('../utils/ref');

// ── helpers ──────────────────────────────────────────────────────────────────
function calcAmount(route, type, seats = 1, cargoSize = 'small') {
  if (type === 'passenger') return route.passenger_price * seats;
  const map = { small: route.cargo_price_sm, medium: route.cargo_price_md, large: route.cargo_price_lg };
  return map[cargoSize] ?? route.cargo_price_sm;
}

// ── POST /api/bookings — public, create a booking ────────────────────────────
router.post('/', async (req, res) => {
  const {
    booking_type = 'passenger',
    route_id, travel_date, travel_time,
    pickup_address, pickup_lat, pickup_lng,
    dropoff_address, dropoff_lat, dropoff_lng,
    payment_method = 'ecocash',
    // passenger
    passenger_name, passenger_phone, seats = 1,
    // cargo
    sender_name, sender_phone,
    receiver_name, receiver_phone,
    cargo_description, cargo_size = 'small', cargo_weight_kg,
  } = req.body;

  // validate required
  if (!route_id || !travel_date || !travel_time)
    return res.status(400).json({ error: 'route_id, travel_date and travel_time are required' });

  if (booking_type === 'passenger' && (!passenger_name || !passenger_phone))
    return res.status(400).json({ error: 'passenger_name and passenger_phone required' });

  if (booking_type === 'cargo' && (!sender_name || !sender_phone || !receiver_name || !receiver_phone))
    return res.status(400).json({ error: 'sender and receiver details required for cargo' });

  try {
    const [routeRows] = await db.query('SELECT * FROM routes WHERE id = ? AND active = 1', [route_id]);
    if (!routeRows.length) return res.status(404).json({ error: 'Route not found or inactive' });
    const route = routeRows[0];

    const amount = calcAmount(route, booking_type, seats, cargo_size);
    const ref    = generateRef(booking_type, route.origin);

    await db.query(`
      INSERT INTO bookings
        (ref, booking_type, route_id, travel_date, travel_time,
         pickup_address, pickup_lat, pickup_lng,
         dropoff_address, dropoff_lat, dropoff_lng,
         amount, payment_method,
         passenger_name, passenger_phone, seats,
         sender_name, sender_phone, receiver_name, receiver_phone,
         cargo_description, cargo_size, cargo_weight_kg)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `, [
      ref, booking_type, route_id, travel_date, travel_time,
      pickup_address, pickup_lat, pickup_lng,
      dropoff_address, dropoff_lat, dropoff_lng,
      amount, payment_method,
      passenger_name || null, passenger_phone || null, booking_type === 'passenger' ? seats : null,
      sender_name || null, sender_phone || null, receiver_name || null, receiver_phone || null,
      cargo_description || null, booking_type === 'cargo' ? cargo_size : null,
      cargo_weight_kg || null,
    ]);

    res.status(201).json({
      message: 'Booking created',
      ref,
      amount,
      payment_method,
      route: `${route.origin} → ${route.destination}`,
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/bookings — admin only, list all with filters ────────────────────
router.get('/', auth, async (req, res) => {
  const { type, status, route_id, date, search } = req.query;
  let sql = `
    SELECT b.*, r.origin, r.destination
    FROM bookings b
    JOIN routes r ON b.route_id = r.id
    WHERE 1=1
  `;
  const params = [];

  if (type)     { sql += ' AND b.booking_type = ?'; params.push(type); }
  if (status)   { sql += ' AND b.status = ?';       params.push(status); }
  if (route_id) { sql += ' AND b.route_id = ?';     params.push(route_id); }
  if (date)     { sql += ' AND b.travel_date = ?';  params.push(date); }
  if (search)   {
    sql += ` AND (b.ref LIKE ? OR b.passenger_name LIKE ? OR b.sender_name LIKE ?
             OR b.passenger_phone LIKE ? OR b.sender_phone LIKE ?)`;
    const like = `%${search}%`;
    params.push(like, like, like, like, like);
  }

  sql += ' ORDER BY b.created_at DESC';

  try {
    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/bookings/track/:ref — public, customer tracking ─────────────────
router.get('/track/:ref', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT b.ref, b.booking_type, b.status, b.travel_date, b.travel_time,
             b.amount, b.payment_method, b.pickup_address, b.dropoff_address,
             b.passenger_name, b.cargo_description, b.cargo_size,
             b.sender_name, b.receiver_name,
             r.origin, r.destination
      FROM bookings b JOIN routes r ON b.route_id = r.id
      WHERE b.ref = ?
    `, [req.params.ref]);
    if (!rows.length) return res.status(404).json({ error: 'Booking not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── PATCH /api/bookings/:id/status — admin only ───────────────────────────────
router.patch('/:id/status', auth, async (req, res) => {
  const { status } = req.body;
  const allowed = ['pending','confirmed','in_transit','completed','cancelled'];
  if (!allowed.includes(status))
    return res.status(400).json({ error: `status must be one of: ${allowed.join(', ')}` });

  try {
    const [result] = await db.query(
      'UPDATE bookings SET status = ? WHERE id = ?', [status, req.params.id]
    );
    if (!result.affectedRows) return res.status(404).json({ error: 'Booking not found' });
    res.json({ message: 'Status updated', status });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ── GET /api/bookings/stats — admin dashboard summary ────────────────────────
router.get('/stats/summary', auth, async (req, res) => {
  try {
    const [[totals]] = await db.query(`
      SELECT
        COUNT(*) AS total,
        SUM(booking_type = 'passenger') AS passengers,
        SUM(booking_type = 'cargo')     AS cargo,
        SUM(status = 'pending')         AS pending,
        SUM(status = 'confirmed')       AS confirmed,
        SUM(status = 'completed')       AS completed,
        SUM(status = 'cancelled')       AS cancelled,
        COALESCE(SUM(CASE WHEN status = 'completed' THEN amount END), 0) AS revenue
      FROM bookings
    `);
    res.json(totals);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
