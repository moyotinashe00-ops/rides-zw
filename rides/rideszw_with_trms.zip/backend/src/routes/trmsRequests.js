const express = require('express');
const router  = express.Router();
const db      = require('../db');
const { trmsAuth } = require('./trmsAuth');

function reqRef() { return 'TR' + Math.floor(Math.random() * 900000 + 100000); }

async function notify(conn, userId, requestId, type, message) {
  await conn.query(
    'INSERT INTO trms_notifications (user_id, request_id, type, message) VALUES (?,?,?,?)',
    [userId, requestId, type, message]
  );
}

// ── POST /api/trms/requests — requester creates a request ────────────────────
router.post('/', trmsAuth(['requester','supervisor','transport_manager','admin']), async (req, res) => {
  const {
    purpose, origin, destination,
    pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
    cargo_description, cargo_weight_kg, required_truck_class,
    requested_date, requested_time, return_required, return_date,
  } = req.body;
  if (!purpose || !origin || !destination || !requested_date || !requested_time)
    return res.status(400).json({ error: 'purpose, origin, destination, requested_date, requested_time required' });

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const ref = reqRef();
    const [result] = await conn.query(`
      INSERT INTO truck_requests
        (ref, requester_id, purpose, origin, destination,
         pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
         cargo_description, cargo_weight_kg, required_truck_class,
         requested_date, requested_time, return_required, return_date)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `, [
      ref, req.trmsUser.id, purpose, origin, destination,
      pickup_lat||null, pickup_lng||null, dropoff_lat||null, dropoff_lng||null,
      cargo_description||null, cargo_weight_kg||null, required_truck_class||'any',
      requested_date, requested_time, return_required||false, return_date||null,
    ]);

    // notify all supervisors
    const [supervisors] = await conn.query('SELECT id FROM trms_users WHERE role = "supervisor" AND active = 1');
    for (const s of supervisors) {
      await notify(conn, s.id, result.insertId, 'submitted',
        `New truck request ${ref} submitted by ${req.trmsUser.name} — ${origin} to ${destination}`);
    }

    await conn.commit();
    res.status(201).json({ message: 'Request submitted', ref });
  } catch (e) {
    await conn.rollback();
    res.status(500).json({ error: e.message });
  } finally { conn.release(); }
});

// ── GET /api/trms/requests — list (filtered by role) ────────────────────────
router.get('/', trmsAuth(), async (req, res) => {
  const { status, date } = req.query;
  const role = req.trmsUser.role;
  let sql = `
    SELECT r.*,
      u.name AS requester_name, u.department,
      s.name AS supervisor_name,
      m.name AS manager_name,
      f.registration AS truck_reg, f.make_model,
      d.name AS driver_name, d.phone AS driver_phone
    FROM truck_requests r
    JOIN trms_users u ON r.requester_id = u.id
    LEFT JOIN trms_users s ON r.supervisor_id = s.id
    LEFT JOIN trms_users m ON r.manager_id = m.id
    LEFT JOIN fleet f ON r.assigned_fleet_id = f.id
    LEFT JOIN drivers d ON r.assigned_driver_id = d.id
    WHERE 1=1
  `;
  const params = [];

  // requesters only see their own
  if (role === 'requester') { sql += ' AND r.requester_id = ?'; params.push(req.trmsUser.id); }
  // supervisors see all pending + their approvals
  if (role === 'supervisor') { sql += ' AND (r.status = "pending" OR r.supervisor_id = ?)'; params.push(req.trmsUser.id); }
  // managers see supervisor-approved + their actions
  if (role === 'transport_manager') { sql += ' AND (r.status = "supervisor_approved" OR r.manager_id = ?)'; params.push(req.trmsUser.id); }

  if (status) { sql += ' AND r.status = ?'; params.push(status); }
  if (date)   { sql += ' AND r.requested_date = ?'; params.push(date); }
  sql += ' ORDER BY r.created_at DESC';

  try {
    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── GET /api/trms/requests/:ref — single request ─────────────────────────────
router.get('/:ref', trmsAuth(), async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT r.*,
        u.name AS requester_name, u.email AS requester_email, u.department,
        s.name AS supervisor_name, m.name AS manager_name,
        f.registration AS truck_reg, f.make_model, f.truck_class,
        d.name AS driver_name, d.phone AS driver_phone, d.license_number
      FROM truck_requests r
      JOIN trms_users u ON r.requester_id = u.id
      LEFT JOIN trms_users s ON r.supervisor_id = s.id
      LEFT JOIN trms_users m ON r.manager_id = m.id
      LEFT JOIN fleet f ON r.assigned_fleet_id = f.id
      LEFT JOIN drivers d ON r.assigned_driver_id = d.id
      WHERE r.ref = ?
    `, [req.params.ref]);
    if (!rows.length) return res.status(404).json({ error: 'Request not found' });
    res.json(rows[0]);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── PATCH /api/trms/requests/:id/cancel — requester cancels ─────────────────
router.patch('/:id/cancel', trmsAuth(), async (req, res) => {
  try {
    const [[req_]] = await db.query('SELECT * FROM truck_requests WHERE id = ?', [req.params.id]);
    if (!req_) return res.status(404).json({ error: 'Not found' });
    if (req_.requester_id !== req.trmsUser.id && req.trmsUser.role !== 'admin')
      return res.status(403).json({ error: 'Forbidden' });
    if (!['pending','supervisor_approved'].includes(req_.status))
      return res.status(400).json({ error: 'Cannot cancel at this stage' });
    await db.query('UPDATE truck_requests SET status = "cancelled" WHERE id = ?', [req.params.id]);
    res.json({ message: 'Request cancelled' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── PATCH /api/trms/requests/:id/supervisor-approve ──────────────────────────
router.patch('/:id/supervisor-approve', trmsAuth(['supervisor','admin']), async (req, res) => {
  const { comment } = req.body;
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [[req_]] = await conn.query('SELECT * FROM truck_requests WHERE id = ?', [req.params.id]);
    if (!req_) return res.status(404).json({ error: 'Not found' });
    if (req_.status !== 'pending') return res.status(400).json({ error: 'Request is not pending' });

    await conn.query(`
      UPDATE truck_requests
      SET status = "supervisor_approved", supervisor_id = ?, supervisor_approved_at = NOW(), supervisor_comment = ?
      WHERE id = ?
    `, [req.trmsUser.id, comment||null, req.params.id]);

    // notify transport managers
    const [managers] = await conn.query('SELECT id FROM trms_users WHERE role = "transport_manager" AND active = 1');
    for (const m of managers) {
      await notify(conn, m.id, req.params.id, 'supervisor_approved',
        `Request ${req_.ref} approved by supervisor — awaiting your approval`);
    }
    // notify requester
    await notify(conn, req_.requester_id, req.params.id, 'supervisor_approved',
      `Your request ${req_.ref} has been approved by supervisor${comment ? ': ' + comment : ''}`);

    await conn.commit();
    res.json({ message: 'Supervisor approval recorded' });
  } catch (e) { await conn.rollback(); res.status(500).json({ error: e.message }); }
  finally { conn.release(); }
});

// ── PATCH /api/trms/requests/:id/manager-approve ─────────────────────────────
router.patch('/:id/manager-approve', trmsAuth(['transport_manager','admin']), async (req, res) => {
  const { comment, fleet_id, driver_id } = req.body;
  if (!fleet_id || !driver_id)
    return res.status(400).json({ error: 'fleet_id and driver_id required when manager approves' });

  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [[req_]] = await conn.query('SELECT * FROM truck_requests WHERE id = ?', [req.params.id]);
    if (!req_) return res.status(404).json({ error: 'Not found' });
    if (req_.status !== 'supervisor_approved') return res.status(400).json({ error: 'Awaiting supervisor approval first' });

    await conn.query(`
      UPDATE truck_requests
      SET status = "assigned",
          manager_id = ?, manager_approved_at = NOW(), manager_comment = ?,
          assigned_fleet_id = ?, assigned_driver_id = ?, assigned_at = NOW()
      WHERE id = ?
    `, [req.trmsUser.id, comment||null, fleet_id, driver_id, req.params.id]);

    // mark fleet + driver as assigned
    await conn.query('UPDATE fleet SET status = "assigned" WHERE id = ?', [fleet_id]);
    await conn.query('UPDATE drivers SET status = "on_trip" WHERE id = ?', [driver_id]);

    // notify requester
    await notify(conn, req_.requester_id, req.params.id, 'assigned',
      `Your request ${req_.ref} has been approved and a truck has been assigned. Check your request for details.`);

    await conn.commit();
    res.json({ message: 'Manager approved, truck and driver assigned' });
  } catch (e) { await conn.rollback(); res.status(500).json({ error: e.message }); }
  finally { conn.release(); }
});

// ── PATCH /api/trms/requests/:id/reject ──────────────────────────────────────
router.patch('/:id/reject', trmsAuth(['supervisor','transport_manager','admin']), async (req, res) => {
  const { reason } = req.body;
  if (!reason) return res.status(400).json({ error: 'Rejection reason required' });
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [[req_]] = await conn.query('SELECT * FROM truck_requests WHERE id = ?', [req.params.id]);
    if (!req_) return res.status(404).json({ error: 'Not found' });

    await conn.query('UPDATE truck_requests SET status = "rejected", rejection_reason = ? WHERE id = ?', [reason, req.params.id]);
    await notify(conn, req_.requester_id, req.params.id, 'rejected',
      `Your request ${req_.ref} was rejected: ${reason}`);

    await conn.commit();
    res.json({ message: 'Request rejected' });
  } catch (e) { await conn.rollback(); res.status(500).json({ error: e.message }); }
  finally { conn.release(); }
});

// ── PATCH /api/trms/requests/:id/start — driver starts trip ─────────────────
router.patch('/:id/start', trmsAuth(['admin','transport_manager']), async (req, res) => {
  try {
    await db.query('UPDATE truck_requests SET status = "in_transit", actual_start = NOW() WHERE id = ? AND status = "assigned"', [req.params.id]);
    res.json({ message: 'Trip started' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ── PATCH /api/trms/requests/:id/complete ────────────────────────────────────
router.patch('/:id/complete', trmsAuth(['admin','transport_manager']), async (req, res) => {
  const { distance_km } = req.body;
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();
    const [[req_]] = await conn.query('SELECT * FROM truck_requests WHERE id = ?', [req.params.id]);
    if (!req_) return res.status(404).json({ error: 'Not found' });

    await conn.query(`
      UPDATE truck_requests SET status = "completed", actual_end = NOW(), distance_km = ? WHERE id = ?
    `, [distance_km||null, req.params.id]);

    // free up fleet and driver
    if (req_.assigned_fleet_id)  await conn.query('UPDATE fleet SET status = "available" WHERE id = ?', [req_.assigned_fleet_id]);
    if (req_.assigned_driver_id) {
      await conn.query('UPDATE drivers SET status = "available", trips_completed = trips_completed + 1 WHERE id = ?', [req_.assigned_driver_id]);
      // log driver trip
      await conn.query(`
        INSERT INTO driver_trips (driver_id, request_id, fleet_id, started_at, ended_at, distance_km)
        VALUES (?,?,?,?,NOW(),?)
      `, [req_.assigned_driver_id, req.params.id, req_.assigned_fleet_id, req_.actual_start, distance_km||null]);
    }
    await notify(conn, req_.requester_id, req.params.id, 'completed', `Your request ${req_.ref} has been completed.`);
    await conn.commit();
    res.json({ message: 'Trip completed' });
  } catch (e) { await conn.rollback(); res.status(500).json({ error: e.message }); }
  finally { conn.release(); }
});

// ── GET /api/trms/requests/stats/summary ─────────────────────────────────────
router.get('/stats/summary', trmsAuth(['admin','transport_manager','supervisor']), async (req, res) => {
  try {
    const [[totals]] = await db.query(`
      SELECT
        COUNT(*) AS total,
        SUM(status = 'pending')              AS pending,
        SUM(status = 'supervisor_approved')  AS supervisor_approved,
        SUM(status = 'assigned')             AS assigned,
        SUM(status = 'in_transit')           AS in_transit,
        SUM(status = 'completed')            AS completed,
        SUM(status = 'rejected')             AS rejected,
        (SELECT COUNT(*) FROM fleet WHERE status = 'available')   AS fleet_available,
        (SELECT COUNT(*) FROM drivers WHERE status = 'available') AS drivers_available
      FROM truck_requests
    `);
    res.json(totals);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

module.exports = router;
