const express = require('express');
const router  = express.Router();
const db      = require('../db');
const auth    = require('../middleware/auth');           // admin JWT
const { ownerAuth } = require('./truckOwners');         // truck owner JWT

// ── ref generator ─────────────────────────────────────────────────
function loadRef() {
  return 'LD' + Math.floor(Math.random() * 900000 + 100000);
}

// ══════════════════════════════════════════════════════════════════
//  PUBLIC — anyone can post a load (shippers don't need an account)
// ══════════════════════════════════════════════════════════════════

// POST /api/loads — shipper posts a load
router.post('/', async (req, res) => {
  const {
    poster_name, poster_phone, poster_email,
    origin, destination, pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
    cargo_description, cargo_weight_kg, cargo_type, required_truck_class,
    pickup_date, pickup_window,
    offered_rate, currency, rate_negotiable, payment_method,
  } = req.body;

  if (!poster_name || !poster_phone || !origin || !destination || !cargo_description || !pickup_date)
    return res.status(400).json({ error: 'poster_name, poster_phone, origin, destination, cargo_description, pickup_date are required' });

  try {
    const ref = loadRef();
    // auto-expire 7 days after pickup date
    const expires = new Date(pickup_date);
    expires.setDate(expires.getDate() + 7);

    await db.query(`
      INSERT INTO loads
        (ref, poster_name, poster_phone, poster_email,
         origin, destination, pickup_lat, pickup_lng, dropoff_lat, dropoff_lng,
         cargo_description, cargo_weight_kg, cargo_type, required_truck_class,
         pickup_date, pickup_window,
         offered_rate, currency, rate_negotiable, payment_method, expires_at)
      VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
    `, [
      ref, poster_name, poster_phone, poster_email||null,
      origin, destination, pickup_lat||null, pickup_lng||null, dropoff_lat||null, dropoff_lng||null,
      cargo_description, cargo_weight_kg||null, cargo_type||'general', required_truck_class||'any',
      pickup_date, pickup_window||null,
      offered_rate||null, currency||'USD', rate_negotiable !== false, payment_method||'ecocash',
      expires.toISOString().split('T')[0],
    ]);
    res.status(201).json({ message: 'Load posted', ref });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/loads — browse open loads (truck owners + public)
router.get('/', async (req, res) => {
  const { origin, destination, truck_class, date, status = 'open' } = req.query;
  let sql = `
    SELECT l.*,
      t.registration AS truck_reg, t.truck_class AS truck_type,
      o.name AS driver_name
    FROM loads l
    LEFT JOIN trucks t ON l.assigned_truck_id = t.id
    LEFT JOIN truck_owners o ON l.assigned_owner_id = o.id
    WHERE l.status = ?
  `;
  const params = [status];

  if (origin)      { sql += ' AND l.origin LIKE ?';      params.push(`%${origin}%`); }
  if (destination) { sql += ' AND l.destination LIKE ?'; params.push(`%${destination}%`); }
  if (date)        { sql += ' AND l.pickup_date = ?';    params.push(date); }
  if (truck_class && truck_class !== 'any') {
    sql += ' AND (l.required_truck_class = ? OR l.required_truck_class = "any")';
    params.push(truck_class);
  }

  sql += ' ORDER BY l.pickup_date ASC, l.created_at DESC';

  try {
    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/loads/:ref — single load detail (public tracking)
router.get('/:ref', async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT l.*, t.registration AS truck_reg, t.make_model,
             o.name AS driver_name, o.phone AS driver_phone, o.rating AS driver_rating
      FROM loads l
      LEFT JOIN trucks t ON l.assigned_truck_id = t.id
      LEFT JOIN truck_owners o ON l.assigned_owner_id = o.id
      WHERE l.ref = ?
    `, [req.params.ref]);
    if (!rows.length) return res.status(404).json({ error: 'Load not found' });

    // include bids if load is still open
    const load = rows[0];
    if (load.status === 'open') {
      const [bids] = await db.query(`
        SELECT b.id, b.bid_amount, b.note, b.status, b.created_at,
               o.name AS bidder_name, o.rating, o.trips_done,
               t.registration, t.truck_class, t.make_model
        FROM load_bids b
        JOIN truck_owners o ON b.owner_id = o.id
        JOIN trucks t ON b.truck_id = t.id
        WHERE b.load_id = ?
        ORDER BY b.bid_amount ASC
      `, [load.id]);
      load.bids = bids;
    }
    res.json(load);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════
//  TRUCK OWNER — bid on loads
// ══════════════════════════════════════════════════════════════════

// POST /api/loads/:ref/bids — truck owner places a bid
router.post('/:ref/bids', ownerAuth, async (req, res) => {
  const { bid_amount, truck_id, note } = req.body;
  if (!bid_amount || !truck_id)
    return res.status(400).json({ error: 'bid_amount and truck_id are required' });

  try {
    // verify truck belongs to owner
    const [trucks] = await db.query(
      'SELECT * FROM trucks WHERE id = ? AND owner_id = ?',
      [truck_id, req.owner.id]
    );
    if (!trucks.length) return res.status(403).json({ error: 'Truck not found or not yours' });

    // get load
    const [loads] = await db.query('SELECT * FROM loads WHERE ref = ?', [req.params.ref]);
    if (!loads.length) return res.status(404).json({ error: 'Load not found' });
    if (loads[0].status !== 'open') return res.status(400).json({ error: 'Load is no longer open' });

    // check no duplicate bid
    const [existing] = await db.query(
      'SELECT id FROM load_bids WHERE load_id = ? AND owner_id = ? AND status = "pending"',
      [loads[0].id, req.owner.id]
    );
    if (existing.length) return res.status(409).json({ error: 'You already have a pending bid on this load' });

    await db.query(
      'INSERT INTO load_bids (load_id, owner_id, truck_id, bid_amount, note) VALUES (?,?,?,?,?)',
      [loads[0].id, req.owner.id, truck_id, bid_amount, note||null]
    );
    res.status(201).json({ message: 'Bid placed' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/loads/owner/:ownerId/bids — truck owner sees their own bids
router.get('/owner/:ownerId/bids', ownerAuth, async (req, res) => {
  if (req.owner.id != req.params.ownerId) return res.status(403).json({ error: 'Forbidden' });
  try {
    const [rows] = await db.query(`
      SELECT b.*, l.ref, l.origin, l.destination, l.pickup_date, l.cargo_description,
             l.offered_rate, l.status AS load_status
      FROM load_bids b
      JOIN loads l ON b.load_id = l.id
      WHERE b.owner_id = ?
      ORDER BY b.created_at DESC
    `, [req.params.ownerId]);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// ══════════════════════════════════════════════════════════════════
//  ADMIN — manage loads and accept bids
// ══════════════════════════════════════════════════════════════════

// GET /api/loads/admin/all — admin sees all loads
router.get('/admin/all', auth, async (req, res) => {
  const { status, search } = req.query;
  let sql = `
    SELECT l.*, t.registration AS truck_reg, o.name AS driver_name
    FROM loads l
    LEFT JOIN trucks t ON l.assigned_truck_id = t.id
    LEFT JOIN truck_owners o ON l.assigned_owner_id = o.id
    WHERE 1=1
  `;
  const params = [];
  if (status) { sql += ' AND l.status = ?'; params.push(status); }
  if (search) {
    sql += ' AND (l.ref LIKE ? OR l.origin LIKE ? OR l.destination LIKE ? OR l.poster_name LIKE ?)';
    const like = `%${search}%`;
    params.push(like, like, like, like);
  }
  sql += ' ORDER BY l.created_at DESC';
  try {
    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// PATCH /api/loads/:id/bids/:bidId/accept — admin accepts a bid → assigns truck
router.patch('/:id/bids/:bidId/accept', auth, async (req, res) => {
  const conn = await db.getConnection();
  try {
    await conn.beginTransaction();

    const [[bid]] = await conn.query('SELECT * FROM load_bids WHERE id = ?', [req.params.bidId]);
    if (!bid) return res.status(404).json({ error: 'Bid not found' });

    // accept this bid
    await conn.query('UPDATE load_bids SET status = "accepted" WHERE id = ?', [bid.id]);
    // reject all others on same load
    await conn.query(
      'UPDATE load_bids SET status = "rejected" WHERE load_id = ? AND id != ?',
      [req.params.id, bid.id]
    );
    // assign truck to load
    await conn.query(
      'UPDATE loads SET status = "assigned", assigned_truck_id = ?, assigned_owner_id = ? WHERE id = ?',
      [bid.truck_id, bid.owner_id, req.params.id]
    );
    // mark truck as on_job
    await conn.query('UPDATE trucks SET status = "on_job" WHERE id = ?', [bid.truck_id]);

    await conn.commit();
    res.json({ message: 'Bid accepted, truck assigned' });
  } catch (e) {
    await conn.rollback();
    res.status(500).json({ error: e.message });
  } finally {
    conn.release();
  }
});

// PATCH /api/loads/:id/status — admin updates load status
router.patch('/:id/status', auth, async (req, res) => {
  const { status } = req.body;
  const allowed = ['open','assigned','in_transit','delivered','expired','cancelled'];
  if (!allowed.includes(status)) return res.status(400).json({ error: 'Invalid status' });
  try {
    const [[load]] = await db.query('SELECT * FROM loads WHERE id = ?', [req.params.id]);
    if (!load) return res.status(404).json({ error: 'Load not found' });
    await db.query('UPDATE loads SET status = ? WHERE id = ?', [status, req.params.id]);
    // free up the truck if delivered or cancelled
    if (['delivered','cancelled'].includes(status) && load.assigned_truck_id) {
      await db.query('UPDATE trucks SET status = "available" WHERE id = ?', [load.assigned_truck_id]);
      if (status === 'delivered') {
        await db.query('UPDATE truck_owners SET trips_done = trips_done + 1 WHERE id = ?', [load.assigned_owner_id]);
      }
    }
    res.json({ message: 'Status updated' });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/loads/stats/summary — admin dashboard stats
router.get('/stats/summary', auth, async (req, res) => {
  try {
    const [[totals]] = await db.query(`
      SELECT
        COUNT(*) AS total,
        SUM(status = 'open')       AS open_loads,
        SUM(status = 'assigned')   AS assigned,
        SUM(status = 'in_transit') AS in_transit,
        SUM(status = 'delivered')  AS delivered,
        (SELECT COUNT(*) FROM truck_owners) AS total_drivers,
        (SELECT COUNT(*) FROM trucks WHERE status = 'available') AS available_trucks,
        (SELECT COUNT(*) FROM load_bids WHERE status = 'pending') AS pending_bids
      FROM loads
    `);
    res.json(totals);
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

module.exports = router;
