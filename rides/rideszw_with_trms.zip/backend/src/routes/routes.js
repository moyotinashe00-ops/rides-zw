const express = require('express');
const router  = express.Router();
const db      = require('../db');
const auth    = require('../middleware/auth');

// GET /api/routes — public, used by the booking form dropdowns
router.get('/', async (req, res) => {
  try {
    const [rows] = await db.query(
      'SELECT * FROM routes WHERE active = 1 ORDER BY origin, destination'
    );
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET /api/routes/:id — single route detail (used for price calculation preview)
router.get('/:id', async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM routes WHERE id = ?', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Route not found' });
    res.json(rows[0]);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// PATCH /api/routes/:id — admin only: update prices / toggle active
router.patch('/:id', auth, async (req, res) => {
  const allowed = ['passenger_price','cargo_price_sm','cargo_price_md','cargo_price_lg','active'];
  const updates = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });
  if (!Object.keys(updates).length) return res.status(400).json({ error: 'Nothing to update' });

  try {
    await db.query('UPDATE routes SET ? WHERE id = ?', [updates, req.params.id]);
    res.json({ message: 'Route updated' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
