const express = require('express');
const router  = express.Router();
const db      = require('../db');
const { trmsAuth } = require('./trmsAuth');

// ══════════════════════════════════════════════════════════════════
//  FLEET
// ══════════════════════════════════════════════════════════════════

// GET /api/trms/fleet
router.get('/fleet', trmsAuth(), async (req, res) => {
  const { status } = req.query;
  let sql = 'SELECT * FROM fleet WHERE 1=1';
  const params = [];
  if (status) { sql += ' AND status = ?'; params.push(status); }
  sql += ' ORDER BY status, make_model';
  try {
    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/trms/fleet — admin/manager registers a truck
router.post('/fleet', trmsAuth(['admin','transport_manager']), async (req, res) => {
  const { registration, make_model, year, truck_class, max_payload_kg, current_location, notes } = req.body;
  if (!registration || !make_model || !truck_class)
    return res.status(400).json({ error: 'registration, make_model, truck_class required' });
  try {
    await db.query(`
      INSERT INTO fleet (registration, make_model, year, truck_class, max_payload_kg, current_location, notes)
      VALUES (?,?,?,?,?,?,?)
    `, [registration, make_model, year||null, truck_class, max_payload_kg||null, current_location||null, notes||null]);
    res.status(201).json({ message: 'Fleet registered' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Registration already exists' });
    res.status(500).json({ error: e.message });
  }
});

// PATCH /api/trms/fleet/:id — update fleet info/status
router.patch('/fleet/:id', trmsAuth(['admin','transport_manager']), async (req, res) => {
  const allowed = ['make_model','year','truck_class','max_payload_kg','status','current_location','last_service_date','next_service_date','notes'];
  const updates = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });
  if (!Object.keys(updates).length) return res.status(400).json({ error: 'Nothing to update' });
  try {
    await db.query('UPDATE fleet SET ? WHERE id = ?', [updates, req.params.id]);
    res.json({ message: 'Fleet updated' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/trms/fleet/:id/maintenance — log a maintenance record
router.post('/fleet/:id/maintenance', trmsAuth(['admin','transport_manager']), async (req, res) => {
  const { type, description, cost, date, next_due, done_by } = req.body;
  if (!type || !date) return res.status(400).json({ error: 'type and date required' });
  try {
    await db.query(`
      INSERT INTO fleet_maintenance (fleet_id, type, description, cost, date, next_due, done_by)
      VALUES (?,?,?,?,?,?,?)
    `, [req.params.id, type, description||null, cost||null, date, next_due||null, done_by||null]);
    // update fleet next service date
    if (next_due) await db.query('UPDATE fleet SET next_service_date = ?, last_service_date = ?, status = "available" WHERE id = ?', [next_due, date, req.params.id]);
    res.status(201).json({ message: 'Maintenance logged' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/trms/fleet/:id/maintenance — history
router.get('/fleet/:id/maintenance', trmsAuth(), async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM fleet_maintenance WHERE fleet_id = ? ORDER BY date DESC', [req.params.id]);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ══════════════════════════════════════════════════════════════════
//  DRIVERS
// ══════════════════════════════════════════════════════════════════

// GET /api/trms/drivers
router.get('/drivers', trmsAuth(), async (req, res) => {
  const { status } = req.query;
  let sql = 'SELECT * FROM drivers WHERE 1=1';
  const params = [];
  if (status) { sql += ' AND status = ?'; params.push(status); }
  sql += ' ORDER BY status, name';
  try {
    const [rows] = await db.query(sql, params);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// POST /api/trms/drivers — register a driver
router.post('/drivers', trmsAuth(['admin','transport_manager']), async (req, res) => {
  const { name, phone, email, license_number, license_expiry, notes } = req.body;
  if (!name || !phone || !license_number || !license_expiry)
    return res.status(400).json({ error: 'name, phone, license_number, license_expiry required' });
  try {
    await db.query(`
      INSERT INTO drivers (name, phone, email, license_number, license_expiry, notes)
      VALUES (?,?,?,?,?,?)
    `, [name, phone, email||null, license_number, license_expiry, notes||null]);
    res.status(201).json({ message: 'Driver registered' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY') return res.status(409).json({ error: 'Phone or license already exists' });
    res.status(500).json({ error: e.message });
  }
});

// PATCH /api/trms/drivers/:id
router.patch('/drivers/:id', trmsAuth(['admin','transport_manager']), async (req, res) => {
  const allowed = ['name','phone','email','license_number','license_expiry','status','notes'];
  const updates = {};
  allowed.forEach(k => { if (req.body[k] !== undefined) updates[k] = req.body[k]; });
  if (!Object.keys(updates).length) return res.status(400).json({ error: 'Nothing to update' });
  try {
    await db.query('UPDATE drivers SET ? WHERE id = ?', [updates, req.params.id]);
    res.json({ message: 'Driver updated' });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// GET /api/trms/drivers/:id/trips — driver trip history
router.get('/drivers/:id/trips', trmsAuth(), async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT dt.*, r.ref, r.origin, r.destination, r.purpose,
             f.registration, f.make_model
      FROM driver_trips dt
      JOIN truck_requests r ON dt.request_id = r.id
      JOIN fleet f ON dt.fleet_id = f.id
      WHERE dt.driver_id = ?
      ORDER BY dt.started_at DESC
    `, [req.params.id]);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ══════════════════════════════════════════════════════════════════
//  NOTIFICATIONS
// ══════════════════════════════════════════════════════════════════

// GET /api/trms/notifications — current user's notifications
router.get('/notifications', trmsAuth(), async (req, res) => {
  try {
    const [rows] = await db.query(`
      SELECT n.*, r.ref, r.origin, r.destination
      FROM trms_notifications n
      JOIN truck_requests r ON n.request_id = r.id
      WHERE n.user_id = ?
      ORDER BY n.created_at DESC
      LIMIT 50
    `, [req.trmsUser.id]);
    res.json(rows);
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// PATCH /api/trms/notifications/:id/read
router.patch('/notifications/:id/read', trmsAuth(), async (req, res) => {
  await db.query('UPDATE trms_notifications SET read_at = NOW() WHERE id = ? AND user_id = ?',
    [req.params.id, req.trmsUser.id]);
  res.json({ message: 'Marked as read' });
});

module.exports = router;
