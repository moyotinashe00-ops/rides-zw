const express  = require('express');
const router   = express.Router();
const bcrypt   = require('bcryptjs');
const jwt      = require('jsonwebtoken');
const db       = require('../db');

// middleware: verify truck owner JWT
function ownerAuth(req, res, next) {
  const header = req.headers['authorization'] || '';
  const token  = header.startsWith('Bearer ') ? header.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'No token' });
  try {
    req.owner = jwt.verify(token, process.env.JWT_SECRET);
    next();
  } catch {
    res.status(401).json({ error: 'Invalid or expired token' });
  }
}

// POST /api/truck-owners/register
router.post('/register', async (req, res) => {
  const { name, phone, email, password, company_name } = req.body;
  if (!name || !phone || !password)
    return res.status(400).json({ error: 'name, phone and password are required' });
  try {
    const hash = await bcrypt.hash(password, 10);
    await db.query(
      'INSERT INTO truck_owners (name, phone, email, password_hash, company_name) VALUES (?,?,?,?,?)',
      [name, phone, email || null, hash, company_name || null]
    );
    res.status(201).json({ message: 'Account created. Await admin verification before bidding.' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: 'Phone number already registered' });
    res.status(500).json({ error: e.message });
  }
});

// POST /api/truck-owners/login
router.post('/login', async (req, res) => {
  const { phone, password } = req.body;
  if (!phone || !password) return res.status(400).json({ error: 'phone and password required' });
  try {
    const [rows] = await db.query('SELECT * FROM truck_owners WHERE phone = ?', [phone]);
    if (!rows.length) return res.status(401).json({ error: 'Invalid credentials' });
    const owner = rows[0];
    const match = await bcrypt.compare(password, owner.password_hash);
    if (!match) return res.status(401).json({ error: 'Invalid credentials' });
    const token = jwt.sign(
      { id: owner.id, name: owner.name, phone: owner.phone, verified: owner.verified },
      process.env.JWT_SECRET,
      { expiresIn: '8h' }
    );
    res.json({ token, id: owner.id, name: owner.name, verified: owner.verified, company: owner.company_name });
  } catch (e) {
    res.status(500).json({ error: e.message });
  }
});

// GET /api/truck-owners/me
router.get('/me', ownerAuth, async (req, res) => {
  const [rows] = await db.query(
    'SELECT id, name, phone, email, company_name, verified, rating, trips_done FROM truck_owners WHERE id = ?',
    [req.owner.id]
  );
  if (!rows.length) return res.status(404).json({ error: 'Not found' });
  res.json(rows[0]);
});

// GET /api/truck-owners/:id/trucks — owner's trucks
router.get('/:id/trucks', ownerAuth, async (req, res) => {
  const [rows] = await db.query('SELECT * FROM trucks WHERE owner_id = ?', [req.params.id]);
  res.json(rows);
});

// POST /api/truck-owners/:id/trucks — add a truck
router.post('/:id/trucks', ownerAuth, async (req, res) => {
  if (req.owner.id != req.params.id) return res.status(403).json({ error: 'Forbidden' });
  const { registration, truck_class, max_payload_kg, make_model, year, current_location } = req.body;
  if (!registration || !truck_class || !max_payload_kg)
    return res.status(400).json({ error: 'registration, truck_class, max_payload_kg required' });
  try {
    await db.query(
      'INSERT INTO trucks (owner_id, registration, truck_class, max_payload_kg, make_model, year, current_location) VALUES (?,?,?,?,?,?,?)',
      [req.params.id, registration, truck_class, max_payload_kg, make_model||null, year||null, current_location||null]
    );
    res.status(201).json({ message: 'Truck added' });
  } catch (e) {
    if (e.code === 'ER_DUP_ENTRY')
      return res.status(409).json({ error: 'Registration already exists' });
    res.status(500).json({ error: e.message });
  }
});

module.exports = { router, ownerAuth };
