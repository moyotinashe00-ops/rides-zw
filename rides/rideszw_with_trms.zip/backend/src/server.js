require('dotenv').config();
const express  = require('express');
const cors     = require('cors');

const authRoutes            = require('./routes/auth');
const routeRoutes           = require('./routes/routes');
const bookingRoutes         = require('./routes/bookings');
const { router: truckOwnerRoutes } = require('./routes/truckOwners');
const loadRoutes            = require('./routes/loads');
const { router: trmsAuthRoutes }   = require('./routes/trmsAuth');
const trmsRequestRoutes     = require('./routes/trmsRequests');
const trmsFleetRoutes       = require('./routes/trmsFleet');

const app  = express();
const PORT = process.env.PORT || 4000;

app.use(cors({
  origin: (process.env.CORS_ORIGIN || '').split(',').map(s => s.trim()),
  credentials: true,
}));
app.use(express.json());

// ── Existing routes ───────────────────────────────────────────────
app.use('/api/auth',         authRoutes);
app.use('/api/routes',       routeRoutes);
app.use('/api/bookings',     bookingRoutes);
app.use('/api/truck-owners', truckOwnerRoutes);
app.use('/api/loads',        loadRoutes);

// ── TRMS routes ───────────────────────────────────────────────────
app.use('/api/trms/auth',     trmsAuthRoutes);
app.use('/api/trms/requests', trmsRequestRoutes);
app.use('/api/trms',          trmsFleetRoutes);   // fleet, drivers, notifications

app.get('/api/health', (_, res) => res.json({ status: 'ok', ts: new Date() }));
app.use((_, res) => res.status(404).json({ error: 'Not found' }));

app.listen(PORT, () => console.log(`🚀 RidesZW + TRMS API running on http://localhost:${PORT}`));
