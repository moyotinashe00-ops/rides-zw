/**
 * Generates a booking reference like MT00042 (passenger) or CG00042 (cargo).
 * Prefix comes from the route origin — same pattern as the original RidesZW.
 */
function generateRef(type = 'passenger', origin = '') {
  const prefix = type === 'cargo'
    ? 'CG'
    : (origin.substring(0, 2).toUpperCase() || 'RZ');
  const num = Math.floor(Math.random() * 90000) + 10000;
  return `${prefix}${num}`;
}

module.exports = { generateRef };
