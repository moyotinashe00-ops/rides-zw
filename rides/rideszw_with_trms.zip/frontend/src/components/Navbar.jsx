import { Link, useLocation } from 'react-router-dom';
import { Bus, Package, MapPin, Truck, LogOut, LogIn, ClipboardList } from 'lucide-react';
import './Navbar.css';

export default function Navbar() {
  const { pathname } = useLocation();
  const owner = (() => { try { return JSON.parse(localStorage.getItem('rzw_owner')); } catch { return null; }})();
  const logout = () => { localStorage.removeItem('rzw_owner'); window.location.href = '/loadboard'; };

  return (
    <nav className="navbar">
      <Link to="/" className="navbar-logo">
        <span className="logo-rides">Rides</span><span className="logo-zw">ZW</span>
      </Link>
      <div className="navbar-links">
        <Link to="/book/passenger" className={pathname.includes('passenger') ? 'active' : ''}>
          <Bus size={15} /> Book a Ride
        </Link>
        <Link to="/book/cargo" className={pathname.includes('cargo') ? 'active' : ''}>
          <Package size={15} /> Send Cargo
        </Link>
        <Link to="/track" className={pathname === '/track' ? 'active' : ''}>
          <MapPin size={15} /> Track
        </Link>
        <Link to="/loadboard" className={pathname.includes('loadboard') || pathname.includes('loads') || pathname.includes('post-load') ? 'active' : ''}>
          <Truck size={15} /> Loadboard
        </Link>
        <Link to="/trms" className={pathname.includes('trms') ? 'active' : ''}>
          <ClipboardList size={15} /> TRMS
        </Link>
        {owner
          ? <button className="navbar-driver-btn" onClick={logout}><LogOut size={13} /> {owner.name?.split(' ')[0]}</button>
          : <Link to="/driver/login" className="navbar-driver-btn"><LogIn size={13} /> Driver Login</Link>
        }
      </div>
    </nav>
  );
}
