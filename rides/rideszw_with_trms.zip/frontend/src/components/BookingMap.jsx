import { useState } from 'react';
import { MapContainer, TileLayer, Marker, useMapEvents } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';

// Fix Leaflet default icon broken by Vite
delete L.Icon.Default.prototype._getIconUrl;
L.Icon.Default.mergeOptions({
  iconRetinaUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon-2x.png',
  iconUrl:       'https://unpkg.com/leaflet@1.9.4/dist/images/marker-icon.png',
  shadowUrl:     'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
});

const pickupIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-green.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41],
});
const dropoffIcon = new L.Icon({
  iconUrl: 'https://raw.githubusercontent.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
  shadowUrl: 'https://unpkg.com/leaflet@1.9.4/dist/images/marker-shadow.png',
  iconSize: [25, 41], iconAnchor: [12, 41],
});

function ClickHandler({ onPickup, onDropoff, mode }) {
  useMapEvents({
    click(e) {
      const { lat, lng } = e.latlng;
      if (mode === 'pickup') onPickup({ lat, lng });
      else onDropoff({ lat, lng });
    }
  });
  return null;
}

export default function BookingMap({ pickup, dropoff, onPickup, onDropoff }) {
  const [mode, setMode] = useState('pickup'); // 'pickup' | 'dropoff'

  return (
    <div className="booking-map-wrapper">
      <div className="map-mode-toggle">
        <button
          className={mode === 'pickup' ? 'active' : ''}
          onClick={() => setMode('pickup')}
        >📍 Set Pickup</button>
        <button
          className={mode === 'dropoff' ? 'active' : ''}
          onClick={() => setMode('dropoff')}
        >🏁 Set Drop-off</button>
      </div>
      <MapContainer
        center={[-17.8292, 31.0522]}  // Harare
        zoom={12}
        style={{ height: 320, width: '100%' }}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='© <a href="https://www.openstreetmap.org/">OpenStreetMap</a>'
        />
        <ClickHandler mode={mode} onPickup={onPickup} onDropoff={onDropoff} />
        {pickup  && <Marker position={[pickup.lat,  pickup.lng]}  icon={pickupIcon} />}
        {dropoff && <Marker position={[dropoff.lat, dropoff.lng]} icon={dropoffIcon} />}
      </MapContainer>
      <p className="map-hint">
        {mode === 'pickup'
          ? '🟢 Click the map to set your pickup point'
          : '🔴 Click the map to set your drop-off point'}
      </p>
    </div>
  );
}
