import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { TRMSProvider } from './context/TRMSContext';
import Navbar from './components/Navbar';
import PassengerBooking from './pages/PassengerBooking';
import CargoBooking from './pages/CargoBooking';
import TrackPage from './pages/TrackPage';
import AdminPage from './pages/AdminPage';
import Loadboard from './pages/Loadboard';
import PostLoad from './pages/PostLoad';
import LoadDetail from './pages/LoadDetail';
import DriverAuth from './pages/DriverAuth';
import TRMSPortal from './pages/trms/TRMSPortal';
import './styles/global.css';

export default function App() {
  return (
    <TRMSProvider>
      <BrowserRouter>
        <Routes>
          {/* Full-page — no navbar */}
          <Route path="/admin/*"          element={<AdminPage />} />
          <Route path="/driver/login"     element={<DriverAuth mode="login" />} />
          <Route path="/driver/register"  element={<DriverAuth mode="register" />} />
          <Route path="/trms/*"           element={<TRMSPortal />} />

          {/* Public pages — shared navbar */}
          <Route path="/*" element={
            <>
              <Navbar />
              <Routes>
                <Route index element={<Navigate to="/book/passenger" replace />} />
                <Route path="book/passenger" element={<PassengerBooking />} />
                <Route path="book/cargo"     element={<CargoBooking />} />
                <Route path="track"          element={<TrackPage />} />
                <Route path="loadboard"      element={<Loadboard />} />
                <Route path="post-load"      element={<PostLoad />} />
                <Route path="loads/:ref"     element={<LoadDetail />} />
              </Routes>
            </>
          } />
        </Routes>
      </BrowserRouter>
    </TRMSProvider>
  );
}
