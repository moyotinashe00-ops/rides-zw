import axios from 'axios';

const api = axios.create({ baseURL: '/api' });

// Attach JWT to every request if present
api.interceptors.request.use(cfg => {
  const token = localStorage.getItem('rzw_token');
  if (token) cfg.headers.Authorization = `Bearer ${token}`;
  return cfg;
});

export default api;
