import { createContext, useContext, useState, useEffect } from 'react';
import api from '../utils/api';

const TRMSContext = createContext(null);

export function TRMSProvider({ children }) {
  const [user, setUser]   = useState(() => {
    try { return JSON.parse(localStorage.getItem('trms_user')); } catch { return null; }
  });
  const [token, setToken] = useState(() => localStorage.getItem('trms_token'));
  const [notifs, setNotifs] = useState([]);

  const login = (data) => {
    localStorage.setItem('trms_token', data.token);
    localStorage.setItem('trms_user', JSON.stringify({ id: data.id, name: data.name, role: data.role, department: data.department }));
    setToken(data.token);
    setUser({ id: data.id, name: data.name, role: data.role, department: data.department });
  };

  const logout = () => {
    localStorage.removeItem('trms_token');
    localStorage.removeItem('trms_user');
    setToken(null); setUser(null);
  };

  // attach trms token to requests under /api/trms
  useEffect(() => {
    if (!token) return;
    const id = api.interceptors.request.use(cfg => {
      if (cfg.url?.startsWith('/api/trms')) cfg.headers.Authorization = `Bearer ${token}`;
      return cfg;
    });
    return () => api.interceptors.request.eject(id);
  }, [token]);

  // load unread notifications
  useEffect(() => {
    if (!token) return;
    api.get('/api/trms/notifications').then(r => setNotifs(r.data.filter(n => !n.read_at))).catch(() => {});
  }, [token]);

  return (
    <TRMSContext.Provider value={{ user, token, login, logout, notifs, setNotifs }}>
      {children}
    </TRMSContext.Provider>
  );
}

export const useTRMS = () => useContext(TRMSContext);
