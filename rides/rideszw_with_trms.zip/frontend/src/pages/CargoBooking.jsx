import { useState, useEffect } from 'react';
import { PackageCheck, MapPin, Calendar, Clock, User, Phone, CreditCard, Weight } from 'lucide-react';
import api from '../utils/api';
import BookingMap from '../components/BookingMap';
import './BookingPage.css';

const SIZES = [
  { value: 'small',  label: 'Small',  desc: 'Parcel, envelope, small box' },
  { value: 'medium', label: 'Medium', desc: 'Suitcase, medium box, up to 30kg' },
  { value: 'large',  label: 'Large',  desc: 'Sack, large box, furniture item' },
];

export default function CargoBooking() {
  const [routes, setRoutes]   = useState([]);
  const [form, setForm]       = useState({
    route_id:'', travel_date:'', travel_time:'',
    sender_name:'', sender_phone:'', receiver_name:'', receiver_phone:'',
    cargo_description:'', cargo_size:'small', cargo_weight_kg:'', payment_method:'ecocash',
  });
  const [pickup, setPickup]   = useState(null);
  const [dropoff, setDropoff] = useState(null);
  const [price, setPrice]     = useState(null);
  const [result, setResult]   = useState(null);
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => { api.get('/routes').then(r => setRoutes(r.data)); }, []);

  useEffect(() => {
    const route = routes.find(r => r.id == form.route_id);
    if (!route) { setPrice(null); return; }
    const map = { small: route.cargo_price_sm, medium: route.cargo_price_md, large: route.cargo_price_lg };
    setPrice(map[form.cargo_size]?.toFixed(2));
  }, [form.route_id, form.cargo_size, routes]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async () => {
    setError(''); setLoading(true);
    try {
      const { data } = await api.post('/bookings', {
        booking_type: 'cargo', ...form,
        pickup_lat: pickup?.lat, pickup_lng: pickup?.lng,
        dropoff_lat: dropoff?.lat, dropoff_lng: dropoff?.lng,
      });
      setResult(data);
    } catch (e) {
      setError(e.response?.data?.error || 'Booking failed. Please try again.');
    } finally { setLoading(false); }
  };

  if (result) return (
    <div className="booking-success">
      <PackageCheck size={56} color="var(--green)" strokeWidth={1.5} />
      <h2>Cargo Booked!</h2>
      <div className="success-ref">{result.ref}</div>
      <p className="success-route">{result.route}</p>
      <div className="success-amount">
        <span>Amount Due</span>
        <strong>${result.amount}</strong>
      </div>
      <div className="payment-instructions">
        <p className="pay-label">Pay via EcoCash</p>
        <code>*151*2*1*0777000000*{result.amount}#</code>
        <p className="pay-note">Reference: <strong>{result.ref}</strong>. Share with your receiver.</p>
      </div>
      <button className="btn-outline" onClick={() => setResult(null)}>Send Another</button>
    </div>
  );

  return (
    <div className="booking-page">
      <div className="booking-hero cargo-hero">
        <div className="booking-hero-text">
          <h1>Send Cargo</h1>
          <p>Fast, tracked parcel & goods delivery across Zimbabwe</p>
        </div>
      </div>
      <div className="booking-body">
        <div className="booking-form card">
          <div className="field">
            <label><MapPin size={13} /> Route</label>
            <select value={form.route_id} onChange={e => set('route_id', e.target.value)}>
              <option value="">Select route</option>
              {routes.map(r => (
                <option key={r.id} value={r.id}>{r.origin} → {r.destination}</option>
              ))}
            </select>
          </div>
          <div className="field-row">
            <div className="field">
              <label><Calendar size={13} /> Send Date</label>
              <input type="date" value={form.travel_date} min={new Date().toISOString().split('T')[0]} onChange={e => set('travel_date', e.target.value)} />
            </div>
            <div className="field">
              <label><Clock size={13} /> Departure Time</label>
              <input type="time" value={form.travel_time} onChange={e => set('travel_time', e.target.value)} />
            </div>
          </div>

          <div className="section-divider">Sender Details</div>
          <div className="field-row">
            <div className="field">
              <label><User size={13} /> Sender Name</label>
              <input type="text" placeholder="Your name" value={form.sender_name} onChange={e => set('sender_name', e.target.value)} />
            </div>
            <div className="field">
              <label><Phone size={13} /> Sender Phone</label>
              <input type="tel" placeholder="+263 7X XXX XXXX" value={form.sender_phone} onChange={e => set('sender_phone', e.target.value)} />
            </div>
          </div>

          <div className="section-divider">Receiver Details</div>
          <div className="field-row">
            <div className="field">
              <label><User size={13} /> Receiver Name</label>
              <input type="text" placeholder="Recipient's name" value={form.receiver_name} onChange={e => set('receiver_name', e.target.value)} />
            </div>
            <div className="field">
              <label><Phone size={13} /> Receiver Phone</label>
              <input type="tel" placeholder="+263 7X XXX XXXX" value={form.receiver_phone} onChange={e => set('receiver_phone', e.target.value)} />
            </div>
          </div>

          <div className="section-divider">Cargo Details</div>
          <div className="field">
            <label>Cargo Description</label>
            <input type="text" placeholder="e.g. Clothes, electronics, groceries..." value={form.cargo_description} onChange={e => set('cargo_description', e.target.value)} />
          </div>
          <div className="field">
            <label>Cargo Size</label>
            <div className="size-grid">
              {SIZES.map(s => (
                <div key={s.value} className={`size-card ${form.cargo_size === s.value ? 'active' : ''}`} onClick={() => set('cargo_size', s.value)}>
                  <strong>{s.label}</strong>
                  <span>{s.desc}</span>
                </div>
              ))}
            </div>
          </div>
          <div className="field">
            <label><Weight size={13} /> Weight (kg) — optional</label>
            <input type="number" placeholder="Approx. weight" value={form.cargo_weight_kg} onChange={e => set('cargo_weight_kg', e.target.value)} />
          </div>
          <div className="field">
            <label><CreditCard size={13} /> Payment Method</label>
            <select value={form.payment_method} onChange={e => set('payment_method', e.target.value)}>
              <option value="ecocash">EcoCash</option>
              <option value="onemoney">OneMoney</option>
              <option value="cash">Cash</option>
            </select>
          </div>
          {price && (
            <div className="price-preview">
              <span>Cargo Cost</span>
              <strong>${price}</strong>
            </div>
          )}
          {error && <p className="error-msg">{error}</p>}
          <button className="btn-gold" onClick={handleSubmit} disabled={loading}>
            {loading ? 'Sending...' : 'Book Cargo'}
          </button>
        </div>
        <div className="booking-map-side">
          <p className="map-label">Pin collection & delivery points</p>
          <BookingMap pickup={pickup} dropoff={dropoff} onPickup={setPickup} onDropoff={setDropoff} />
        </div>
      </div>
    </div>
  );
}
