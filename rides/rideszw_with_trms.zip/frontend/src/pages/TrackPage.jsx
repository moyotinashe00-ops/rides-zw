import { useState } from 'react';
import { Search, CheckCircle, Circle, ArrowRight } from 'lucide-react';
import api from '../utils/api';
import './TrackPage.css';

const STATUS_STEPS = ['pending','confirmed','in_transit','completed'];

export default function TrackPage() {
  const [ref, setRef]         = useState('');
  const [booking, setBooking] = useState(null);
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const handleTrack = async () => {
    if (!ref.trim()) return;
    setError(''); setBooking(null); setLoading(true);
    try {
      const { data } = await api.get(`/bookings/track/${ref.trim().toUpperCase()}`);
      setBooking(data);
    } catch (e) {
      setError(e.response?.data?.error || 'Booking not found. Check your reference and try again.');
    } finally { setLoading(false); }
  };

  const stepIdx = booking ? STATUS_STEPS.indexOf(booking.status) : -1;

  return (
    <div className="track-page">
      <div className="track-hero">
        <h1>Track Your Booking</h1>
        <p>Enter your booking reference number to check status</p>
      </div>
      <div className="track-search card">
        <div className="search-row">
          <input
            type="text"
            placeholder="e.g. MT12345 or CG67890"
            value={ref}
            onChange={e => setRef(e.target.value)}
            onKeyDown={e => e.key === 'Enter' && handleTrack()}
          />
          <button className="btn-primary" onClick={handleTrack} disabled={loading}>
            <Search size={16} /> {loading ? '...' : 'Track'}
          </button>
        </div>
        {error && <p className="error-msg">{error}</p>}
      </div>

      {booking && (
        <div className="track-result card">
          <div className="track-header">
            <div>
              <span className={`tag-${booking.booking_type}`}>{booking.booking_type}</span>
              <h2 className="track-ref">{booking.ref}</h2>
              <p className="track-route">{booking.origin} <ArrowRight size={14} /> {booking.destination}</p>
            </div>
            <div className={`badge badge-${booking.status}`}>{booking.status.replace('_',' ')}</div>
          </div>

          {booking.status !== 'cancelled' && (
            <div className="status-steps">
              {STATUS_STEPS.map((s, i) => (
                <div key={s} className={`step ${i <= stepIdx ? 'done' : ''} ${i === stepIdx ? 'current' : ''}`}>
                  <div className="step-dot">
                    {i < stepIdx
                      ? <CheckCircle size={16} />
                      : <Circle size={16} />
                    }
                  </div>
                  <span>{s.replace('_',' ')}</span>
                  {i < STATUS_STEPS.length - 1 && <div className="step-line" />}
                </div>
              ))}
            </div>
          )}

          <div className="track-details">
            <div className="detail-row">
              <span>Date</span>
              <strong>{new Date(booking.travel_date).toLocaleDateString('en-ZW', { weekday:'short', day:'numeric', month:'long', year:'numeric' })}</strong>
            </div>
            <div className="detail-row"><span>Time</span><strong>{booking.travel_time}</strong></div>
            {booking.booking_type === 'passenger' && (
              <div className="detail-row"><span>Passenger</span><strong>{booking.passenger_name}</strong></div>
            )}
            {booking.booking_type === 'cargo' && (<>
              <div className="detail-row"><span>Sender</span><strong>{booking.sender_name}</strong></div>
              <div className="detail-row"><span>Receiver</span><strong>{booking.receiver_name}</strong></div>
              <div className="detail-row"><span>Cargo</span><strong>{booking.cargo_description} ({booking.cargo_size})</strong></div>
            </>)}
            <div className="detail-row amount-row">
              <span>Amount</span>
              <strong className="amount-val">${booking.amount}</strong>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
