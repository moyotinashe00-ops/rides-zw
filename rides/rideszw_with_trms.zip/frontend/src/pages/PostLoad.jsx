import { useState } from 'react';
import { Truck, MapPin, Package, Calendar, Clock, User, Phone, Mail, DollarSign, CheckCircle } from 'lucide-react';
import api from '../utils/api';
import BookingMap from '../components/BookingMap';
import './LoadboardPage.css';

const CARGO_TYPES = ['general','perishable','hazmat','livestock','machinery','furniture','other'];
const TRUCK_CLASSES = ['any','pickup','1_3ton','5ton','10ton','flatbed','tanker','refrigerated'];

export default function PostLoad() {
  const [form, setForm] = useState({
    poster_name:'', poster_phone:'', poster_email:'',
    origin:'', destination:'',
    cargo_description:'', cargo_weight_kg:'', cargo_type:'general',
    required_truck_class:'any',
    pickup_date:'', pickup_window:'',
    offered_rate:'', rate_negotiable:true, payment_method:'ecocash',
  });
  const [pickup, setPickup]   = useState(null);
  const [dropoff, setDropoff] = useState(null);
  const [result, setResult]   = useState(null);
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async () => {
    setError(''); setLoading(true);
    try {
      const { data } = await api.post('/loads', {
        ...form,
        pickup_lat: pickup?.lat, pickup_lng: pickup?.lng,
        dropoff_lat: dropoff?.lat, dropoff_lng: dropoff?.lng,
        cargo_weight_kg: form.cargo_weight_kg || null,
        offered_rate: form.offered_rate || null,
      });
      setResult(data);
    } catch (e) {
      setError(e.response?.data?.error || 'Failed to post load. Please try again.');
    } finally { setLoading(false); }
  };

  if (result) return (
    <div className="post-success">
      <CheckCircle size={56} color="var(--green)" strokeWidth={1.5} />
      <h2>Load Posted!</h2>
      <div className="load-ref">{result.ref}</div>
      <p>Truck owners can now see and bid on your load.</p>
      <div className="success-actions">
        <button className="btn-primary" onClick={() => window.location.href = '/loadboard'}>Browse Loadboard</button>
        <button className="btn-outline" onClick={() => setResult(null)}>Post Another</button>
      </div>
    </div>
  );

  return (
    <div className="loadboard-page">
      <div className="lb-hero post-hero">
        <div className="lb-hero-text">
          <span className="lb-tag">Truck Drive</span>
          <h1>Post a Load</h1>
          <p>Connect with verified truck owners across Zimbabwe</p>
        </div>
      </div>
      <div className="lb-form-layout">
        <div className="lb-form card">
          <div className="form-section-title">Your Details</div>
          <div className="field-row">
            <div className="field"><label><User size={13} /> Full Name</label><input type="text" placeholder="Your name" value={form.poster_name} onChange={e => set('poster_name', e.target.value)} /></div>
            <div className="field"><label><Phone size={13} /> Phone</label><input type="tel" placeholder="+263 7X XXX XXXX" value={form.poster_phone} onChange={e => set('poster_phone', e.target.value)} /></div>
          </div>
          <div className="field"><label><Mail size={13} /> Email (optional)</label><input type="email" placeholder="for updates" value={form.poster_email} onChange={e => set('poster_email', e.target.value)} /></div>

          <div className="form-section-title">Route</div>
          <div className="field-row">
            <div className="field"><label><MapPin size={13} /> Pickup Location</label><input type="text" placeholder="e.g. Mbare, Harare" value={form.origin} onChange={e => set('origin', e.target.value)} /></div>
            <div className="field"><label><MapPin size={13} /> Delivery Location</label><input type="text" placeholder="e.g. Bulawayo CBD" value={form.destination} onChange={e => set('destination', e.target.value)} /></div>
          </div>

          <div className="form-section-title">Cargo</div>
          <div className="field"><label><Package size={13} /> Cargo Description</label><input type="text" placeholder="What are you shipping?" value={form.cargo_description} onChange={e => set('cargo_description', e.target.value)} /></div>
          <div className="field-row">
            <div className="field"><label>Weight (kg) — optional</label><input type="number" placeholder="Approx. weight" value={form.cargo_weight_kg} onChange={e => set('cargo_weight_kg', e.target.value)} /></div>
            <div className="field">
              <label>Cargo Type</label>
              <select value={form.cargo_type} onChange={e => set('cargo_type', e.target.value)}>
                {CARGO_TYPES.map(t => <option key={t} value={t}>{t.charAt(0).toUpperCase() + t.slice(1)}</option>)}
              </select>
            </div>
          </div>
          <div className="field">
            <label><Truck size={13} /> Required Truck Type</label>
            <select value={form.required_truck_class} onChange={e => set('required_truck_class', e.target.value)}>
              {TRUCK_CLASSES.map(t => <option key={t} value={t}>{t === 'any' ? 'Any truck' : t}</option>)}
            </select>
          </div>

          <div className="form-section-title">Schedule</div>
          <div className="field-row">
            <div className="field"><label><Calendar size={13} /> Pickup Date</label><input type="date" value={form.pickup_date} min={new Date().toISOString().split('T')[0]} onChange={e => set('pickup_date', e.target.value)} /></div>
            <div className="field"><label><Clock size={13} /> Pickup Window</label><input type="text" placeholder="e.g. 08:00 - 12:00" value={form.pickup_window} onChange={e => set('pickup_window', e.target.value)} /></div>
          </div>

          <div className="form-section-title">Rate & Payment</div>
          <div className="field-row">
            <div className="field"><label><DollarSign size={13} /> Offered Rate (USD)</label><input type="number" placeholder="Leave blank if negotiable" value={form.offered_rate} onChange={e => set('offered_rate', e.target.value)} /></div>
            <div className="field">
              <label>Payment Method</label>
              <select value={form.payment_method} onChange={e => set('payment_method', e.target.value)}>
                <option value="ecocash">EcoCash</option>
                <option value="onemoney">OneMoney</option>
                <option value="cash">Cash</option>
                <option value="bank">Bank Transfer</option>
              </select>
            </div>
          </div>
          <div className="field checkbox-field">
            <label><input type="checkbox" checked={form.rate_negotiable} onChange={e => set('rate_negotiable', e.target.checked)} /> Rate is negotiable</label>
          </div>

          {error && <p className="error-msg">{error}</p>}
          <button className="btn-gold" onClick={handleSubmit} disabled={loading}>
            <Truck size={16} /> {loading ? 'Posting...' : 'Post Load'}
          </button>
        </div>
        <div className="lb-map-side">
          <p className="map-label">Pin pickup & delivery points</p>
          <BookingMap pickup={pickup} dropoff={dropoff} onPickup={setPickup} onDropoff={setDropoff} />
        </div>
      </div>
    </div>
  );
}
