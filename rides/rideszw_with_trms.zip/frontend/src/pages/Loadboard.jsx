import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { Package, Truck, Calendar, Clock, DollarSign, User, Search, Plus, ArrowRight } from 'lucide-react';
import api from '../utils/api';
import './LoadboardPage.css';

const TRUCK_CLASSES = ['any','pickup','1_3ton','5ton','10ton','flatbed','tanker','refrigerated'];

const cargoIcon = (type) => {
  const icons = { general: Package, perishable: Package, hazmat: Package, livestock: Package, machinery: Truck, furniture: Package, other: Package };
  const Icon = icons[type] || Package;
  return <Icon size={14} />;
};

export default function Loadboard() {
  const [loads, setLoads]     = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter]   = useState({ origin:'', destination:'', truck_class:'any', date:'' });

  const fetchLoads = async () => {
    setLoading(true);
    try {
      const params = { status: 'open' };
      if (filter.origin)      params.origin      = filter.origin;
      if (filter.destination) params.destination = filter.destination;
      if (filter.date)        params.date        = filter.date;
      if (filter.truck_class !== 'any') params.truck_class = filter.truck_class;
      const { data } = await api.get('/loads', { params });
      setLoads(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchLoads(); }, []);

  return (
    <div className="loadboard-page">
      <div className="lb-hero browse-hero">
        <div className="lb-hero-text">
          <span className="lb-tag">Truck Drive</span>
          <h1>Available Loads</h1>
          <p>Find freight that matches your route and truck</p>
        </div>
        <Link to="/post-load" className="btn-gold hero-post-btn"><Plus size={16} /> Post a Load</Link>
      </div>

      <div className="lb-filters card">
        <input placeholder="From (origin)" value={filter.origin} onChange={e => setFilter(f => ({...f, origin: e.target.value}))} />
        <input placeholder="To (destination)" value={filter.destination} onChange={e => setFilter(f => ({...f, destination: e.target.value}))} />
        <select value={filter.truck_class} onChange={e => setFilter(f => ({...f, truck_class: e.target.value}))}>
          {TRUCK_CLASSES.map(t => <option key={t} value={t}>{t === 'any' ? 'All truck types' : t}</option>)}
        </select>
        <input type="date" value={filter.date} onChange={e => setFilter(f => ({...f, date: e.target.value}))} />
        <button className="btn-primary" onClick={fetchLoads}><Search size={15} /> Search</button>
      </div>

      <div className="lb-results">
        {loading && <p className="lb-loading">Loading loads...</p>}
        {!loading && loads.length === 0 && (
          <div className="lb-empty">
            <Search size={48} color="var(--muted)" />
            <p>No open loads found. Try adjusting your filters.</p>
            <Link to="/post-load" className="btn-outline">Be the first to post a load</Link>
          </div>
        )}
        {loads.map(load => (
          <Link to={`/loads/${load.ref}`} key={load.id} className="load-card">
            <div className="load-card-left">
              <div className="load-ref-badge">{load.ref}</div>
              <div className="load-route">
                <span className="route-from">{load.origin}</span>
                <ArrowRight size={18} color="var(--gold)" />
                <span className="route-to">{load.destination}</span>
              </div>
              <div className="load-meta">
                {cargoIcon(load.cargo_type)} {load.cargo_description}
                {load.cargo_weight_kg && <span> · {load.cargo_weight_kg} kg</span>}
              </div>
              <div className="load-tags">
                <span className="tag-truck"><Truck size={11} /> {load.required_truck_class === 'any' ? 'Any truck' : load.required_truck_class}</span>
                <span className="tag-payment">{load.payment_method}</span>
                {load.cargo_type !== 'general' && <span className="tag-cargo">{load.cargo_type}</span>}
              </div>
            </div>
            <div className="load-card-right">
              <div className="load-date"><Calendar size={13} /> {new Date(load.pickup_date).toLocaleDateString('en-ZW', { weekday:'short', day:'numeric', month:'short' })}</div>
              {load.pickup_window && <div className="load-window"><Clock size={13} /> {load.pickup_window}</div>}
              <div className="load-rate">
                {load.offered_rate
                  ? <><strong>${load.offered_rate}</strong>{load.rate_negotiable && <span className="neg-tag">neg.</span>}</>
                  : <span className="negotiable">Negotiable</span>
                }
              </div>
              <div className="load-poster"><User size={12} /> {load.poster_name}</div>
              <div className="bid-cta">View & Bid <ArrowRight size={13} /></div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
