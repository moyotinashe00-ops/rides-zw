import { useState, useEffect } from 'react';
import { useParams, Link } from 'react-router-dom';
import { ArrowLeft, Package, Truck, Calendar, Clock, DollarSign, User, Phone, Star, MapPin, Share2, Lock, HandshakeIcon } from 'lucide-react';
import api from '../utils/api';
import './LoadboardPage.css';

export default function LoadDetail() {
  const { ref }               = useParams();
  const [load, setLoad]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState('');

  const [owner] = useState(() => {
    try { return JSON.parse(localStorage.getItem('rzw_owner')); } catch { return null; }
  });
  const [trucks, setTrucks]         = useState([]);
  const [bid, setBid]               = useState({ truck_id:'', bid_amount:'', note:'' });
  const [bidSuccess, setBidSuccess] = useState('');
  const [bidError, setBidError]     = useState('');
  const [bidLoading, setBidLoading] = useState(false);

  useEffect(() => {
    api.get(`/loads/${ref}`)
      .then(r => setLoad(r.data))
      .catch(() => setError('Load not found'))
      .finally(() => setLoading(false));
  }, [ref]);

  useEffect(() => {
    if (owner) {
      api.get(`/truck-owners/${owner.id}/trucks`, {
        headers: { Authorization: `Bearer ${owner.token}` }
      }).then(r => setTrucks(r.data)).catch(() => {});
    }
  }, [owner]);

  const placeBid = async () => {
    setBidError(''); setBidLoading(true);
    try {
      await api.post(`/loads/${ref}/bids`, bid, {
        headers: { Authorization: `Bearer ${owner.token}` }
      });
      setBidSuccess('Bid placed! The shipper will be notified.');
      setBid({ truck_id:'', bid_amount:'', note:'' });
      const { data } = await api.get(`/loads/${ref}`);
      setLoad(data);
    } catch (e) {
      setBidError(e.response?.data?.error || 'Bid failed');
    } finally { setBidLoading(false); }
  };

  const statusColor = {
    open:'badge-confirmed', assigned:'badge-in_transit',
    in_transit:'badge-in_transit', delivered:'badge-completed',
    cancelled:'badge-cancelled', expired:'badge-cancelled'
  };

  if (loading) return <div className="lb-loading-full">Loading...</div>;
  if (error)   return <div className="lb-error">{error}</div>;
  if (!load)   return null;

  return (
    <div className="loadboard-page">
      <div className="load-detail-header">
        <Link to="/loadboard" className="back-link"><ArrowLeft size={15} /> Back to Loadboard</Link>
        <div className="load-detail-ref">
          <span className="load-ref-badge lg">{load.ref}</span>
          <span className={`badge ${statusColor[load.status] || 'badge-pending'}`}>{load.status.replace('_',' ')}</span>
        </div>
      </div>

      <div className="load-detail-layout">
        <div className="load-detail-main">
          <div className="card load-info-card">
            <div className="detail-route">
              <div className="detail-city from">{load.origin}</div>
              <div className="route-line"><ArrowLeft size={24} style={{transform:'rotate(180deg)'}} color="var(--gold)" /></div>
              <div className="detail-city to">{load.destination}</div>
            </div>
            <div className="detail-grid">
              <div className="detail-item"><span><Package size={12} /> Cargo</span><strong>{load.cargo_description}</strong></div>
              {load.cargo_weight_kg && <div className="detail-item"><span>Weight</span><strong>{load.cargo_weight_kg} kg</strong></div>}
              <div className="detail-item"><span><Truck size={12} /> Truck needed</span><strong>{load.required_truck_class === 'any' ? 'Any' : load.required_truck_class}</strong></div>
              <div className="detail-item"><span><Calendar size={12} /> Pickup date</span><strong>{new Date(load.pickup_date).toLocaleDateString('en-ZW', { weekday:'long', day:'numeric', month:'long' })}</strong></div>
              {load.pickup_window && <div className="detail-item"><span><Clock size={12} /> Time window</span><strong>{load.pickup_window}</strong></div>}
              <div className="detail-item"><span><DollarSign size={12} /> Rate</span><strong>{load.offered_rate ? `$${load.offered_rate}${load.rate_negotiable ? ' (neg.)' : ''}` : 'Negotiable'}</strong></div>
              <div className="detail-item"><span>Payment</span><strong>{load.payment_method}</strong></div>
              <div className="detail-item"><span><User size={12} /> Posted by</span><strong>{load.poster_name}</strong></div>
            </div>
          </div>

          {load.assigned_truck_id && (
            <div className="card assigned-card">
              <h3><Truck size={16} /> Assigned Truck</h3>
              <div className="detail-grid">
                <div className="detail-item"><span>Driver</span><strong>{load.driver_name}</strong></div>
                <div className="detail-item"><span>Truck</span><strong>{load.truck_reg} · {load.make_model}</strong></div>
                <div className="detail-item"><span><Star size={12} /> Rating</span><strong>{load.driver_rating || 'N/A'}</strong></div>
                <div className="detail-item"><span><Phone size={12} /> Phone</span><strong>{load.driver_phone}</strong></div>
              </div>
            </div>
          )}

          {load.bids && load.bids.length > 0 && (
            <div className="card bids-card">
              <h3>Bids ({load.bids.length})</h3>
              {load.bids.map(b => (
                <div key={b.id} className={`bid-row ${b.status}`}>
                  <div className="bid-info">
                    <strong>{b.bidder_name}</strong>
                    <span>{b.registration} · {b.truck_class}</span>
                    {b.note && <p className="bid-note">{b.note}</p>}
                  </div>
                  <div className="bid-amount">
                    <strong>${b.bid_amount}</strong>
                    <span><Star size={11} /> {b.rating || 'New'} · {b.trips_done} trips</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="load-detail-side">
          {load.status === 'open' ? (
            owner ? (
              <div className="card bid-form-card">
                <h3>Place Your Bid</h3>
                {bidSuccess && <p className="success-msg">{bidSuccess}</p>}
                {!bidSuccess && (<>
                  <div className="field">
                    <label><Truck size={13} /> Select Your Truck</label>
                    <select value={bid.truck_id} onChange={e => setBid(b => ({...b, truck_id: e.target.value}))}>
                      <option value="">Choose truck</option>
                      {trucks.filter(t => t.status === 'available').map(t => (
                        <option key={t.id} value={t.id}>{t.registration} — {t.truck_class} ({t.max_payload_kg}kg)</option>
                      ))}
                    </select>
                  </div>
                  <div className="field">
                    <label><DollarSign size={13} /> Your Rate (USD)</label>
                    <input type="number" placeholder={load.offered_rate ? `Shipper offered $${load.offered_rate}` : 'Enter your rate'} value={bid.bid_amount} onChange={e => setBid(b => ({...b, bid_amount: e.target.value}))} />
                  </div>
                  <div className="field">
                    <label>Note to shipper (optional)</label>
                    <textarea rows={3} placeholder="Any details about your truck, ETA, etc." value={bid.note} onChange={e => setBid(b => ({...b, note: e.target.value}))} />
                  </div>
                  {bidError && <p className="error-msg">{bidError}</p>}
                  <button className="btn-gold" onClick={placeBid} disabled={bidLoading || !bid.truck_id || !bid.bid_amount}>
                    Submit Bid
                  </button>
                </>)}
              </div>
            ) : (
              <div className="card bid-login-card">
                <h3>Want this load?</h3>
                <p>Sign in as a truck owner to place a bid.</p>
                <Link to="/driver/login" className="btn-primary">Driver Login</Link>
                <Link to="/driver/register" className="btn-outline">Register as Driver</Link>
              </div>
            )
          ) : (
            <div className="card load-closed-card">
              <Lock size={36} color="var(--muted)" />
              <p>This load is {load.status} and no longer accepting bids.</p>
            </div>
          )}

          <div className="card share-card">
            <h4><Share2 size={14} /> Share this load</h4>
            <p className="share-ref">{load.ref}</p>
            <button className="btn-outline" onClick={() => navigator.clipboard.writeText(window.location.href)}>
              Copy Link
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
