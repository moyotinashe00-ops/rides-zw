import { useState, useEffect } from 'react';
import { CheckCircle, MapPin, Calendar, Clock, User, Phone, CreditCard } from 'lucide-react';
import api from '../utils/api';
import BookingMap from '../components/BookingMap';
import './BookingPage.css';

export default function PassengerBooking() {
  const [routes, setRoutes]   = useState([]);
  const [form, setForm]       = useState({ route_id:'', travel_date:'', travel_time:'', seats:1, passenger_name:'', passenger_phone:'', payment_method:'ecocash' });
  const [pickup, setPickup]   = useState(null);
  const [dropoff, setDropoff] = useState(null);
  const [price, setPrice]     = useState(null);
  const [result, setResult]   = useState(null);
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);

  useEffect(() => { api.get('/routes').then(r => setRoutes(r.data)); }, []);

  useEffect(() => {
    const route = routes.find(r => r.id == form.route_id);
    if (route) setPrice((route.passenger_price * form.seats).toFixed(2));
    else setPrice(null);
  }, [form.route_id, form.seats, routes]);

  const set = (k, v) => setForm(f => ({ ...f, [k]: v }));

  const handleSubmit = async () => {
    setError(''); setLoading(true);
    try {
      const { data } = await api.post('/bookings', {
        booking_type: 'passenger', ...form, seats: parseInt(form.seats),
        pickup_lat: pickup?.lat, pickup_lng: pickup?.lng,
        dropoff_lat: dropoff?.lat, dropoff_lng: dropoff?.lng,
      });
      setResult(data);
    } catch (e) {
      setError(e.response?.data?.error || 'Booking failed. Please try again.');
    } finally { setLoading(false); }
  };

  if (result) return (
    <div className="booking-success">
      <CheckCircle size={56} color="var(--green)" strokeWidth={1.5} />
      <h2>Booking Confirmed!</h2>
      <div className="success-ref">{result.ref}</div>
      <p className="success-route">{result.route}</p>
      <div className="success-amount">
        <span>Amount Due</span>
        <strong>${result.amount}</strong>
      </div>
      <div className="payment-instructions">
        <p className="pay-label">Pay via EcoCash</p>
        <code>*151*2*1*0777000000*{result.amount}#</code>
        <p className="pay-note">Use reference <strong>{result.ref}</strong> as payment reference.</p>
      </div>
      <button className="btn-outline" onClick={() => setResult(null)}>Make Another Booking</button>
    </div>
  );

  return (
    <div className="booking-page">
      <div className="booking-hero">
        <div className="booking-hero-text">
          <h1>Book a Ride</h1>
          <p>Comfortable intercity travel across Zimbabwe</p>
        </div>
      </div>
      <div className="booking-body">
        <div className="booking-form card">
          <div className="field">
            <label><MapPin size={13} /> Route</label>
            <select value={form.route_id} onChange={e => set('route_id', e.target.value)}>
              <option value="">Select route</option>
              {routes.map(r => (
                <option key={r.id} value={r.id}>{r.origin} → {r.destination} (${r.passenger_price}/seat)</option>
              ))}
            </select>
          </div>
          <div className="field-row">
            <div className="field">
              <label><Calendar size={13} /> Travel Date</label>
              <input type="date" value={form.travel_date} min={new Date().toISOString().split('T')[0]} onChange={e => set('travel_date', e.target.value)} />
            </div>
            <div className="field">
              <label><Clock size={13} /> Departure Time</label>
              <input type="time" value={form.travel_time} onChange={e => set('travel_time', e.target.value)} />
            </div>
          </div>
          <div className="field">
            <label>Number of Seats</label>
            <input type="number" min="1" max="10" value={form.seats} onChange={e => set('seats', e.target.value)} />
          </div>
          <div className="field-row">
            <div className="field">
              <label><User size={13} /> Your Name</label>
              <input type="text" placeholder="Full name" value={form.passenger_name} onChange={e => set('passenger_name', e.target.value)} />
            </div>
            <div className="field">
              <label><Phone size={13} /> Phone Number</label>
              <input type="tel" placeholder="+263 7X XXX XXXX" value={form.passenger_phone} onChange={e => set('passenger_phone', e.target.value)} />
            </div>
          </div>
          <div className="field">
            <label><CreditCard size={13} /> Payment Method</label>
            <select value={form.payment_method} onChange={e => set('payment_method', e.target.value)}>
              <option value="ecocash">EcoCash</option>
              <option value="onemoney">OneMoney</option>
              <option value="cash">Cash</option>
            </select>
          </div>
          {price && (
            <div className="price-preview">
              <span>Total</span>
              <strong>${price}</strong>
            </div>
          )}
          {error && <p className="error-msg">{error}</p>}
          <button className="btn-primary" onClick={handleSubmit} disabled={loading}>
            {loading ? 'Booking...' : 'Confirm Booking'}
          </button>
        </div>
        <div className="booking-map-side">
          <p className="map-label">Pin your pickup & drop-off on the map</p>
          <BookingMap pickup={pickup} dropoff={dropoff} onPickup={setPickup} onDropoff={setDropoff} />
        </div>
      </div>
    </div>
  );
}
