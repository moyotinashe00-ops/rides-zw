import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { MapPin, Calendar, Clock, FileText, Truck, Package, RotateCcw, CheckCircle } from 'lucide-react';
import api from '../../utils/api';
import BookingMap from '../../components/BookingMap';

const TRUCK_CLASSES = ['any','pickup','1_3ton','5ton','10ton','flatbed','tanker','refrigerated'];

export default function TRMSNewRequest() {
  const navigate = useNavigate();
  const [form, setForm] = useState({
    purpose: '', origin: '', destination: '',
    cargo_description: '', cargo_weight_kg: '',
    required_truck_class: 'any',
    requested_date: '', requested_time: '',
    return_required: false, return_date: '',
  });
  const [pickup, setPickup]   = useState(null);
  const [dropoff, setDropoff] = useState(null);
  const [error, setError]     = useState('');
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(null);

  const set = (k, v) => setForm(f => ({...f, [k]: v}));

  const handleSubmit = async () => {
    setError(''); setLoading(true);
    try {
      const { data } = await api.post('/api/trms/requests', {
        ...form,
        pickup_lat: pickup?.lat, pickup_lng: pickup?.lng,
        dropoff_lat: dropoff?.lat, dropoff_lng: dropoff?.lng,
        cargo_weight_kg: form.cargo_weight_kg || null,
        return_date: form.return_required ? form.return_date : null,
      });
      setSuccess(data.ref);
    } catch (e) {
      setError(e.response?.data?.error || 'Submission failed');
    } finally { setLoading(false); }
  };

  if (success) return (
    <div className="trms-page">
      <div className="trms-success-screen">
        <CheckCircle size={56} color="var(--green)" strokeWidth={1.5} />
        <h2>Request Submitted!</h2>
        <div className="trms-success-ref">{success}</div>
        <p>Your request has been sent to supervisors for approval. You will be notified at each stage.</p>
        <div className="trms-success-actions">
          <button className="btn-primary" onClick={() => navigate(`/trms/requests/${success}`)}>View Request</button>
          <button className="btn-outline" onClick={() => { setSuccess(null); setForm({ purpose:'',origin:'',destination:'',cargo_description:'',cargo_weight_kg:'',required_truck_class:'any',requested_date:'',requested_time:'',return_required:false,return_date:'' }); }}>
            New Request
          </button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="trms-page">
      <div className="trms-page-header">
        <div>
          <h1>New Truck Request</h1>
          <p className="trms-page-sub">Fill in trip details — your supervisor will be notified immediately</p>
        </div>
      </div>

      <div className="trms-form-layout">
        <div className="trms-form card">

          <div className="trms-form-section">Trip Details</div>
          <div className="field">
            <label><FileText size={13} /> Purpose of Trip</label>
            <input type="text" placeholder="e.g. Delivery of goods to Bulawayo branch" value={form.purpose} onChange={e => set('purpose', e.target.value)} />
          </div>

          <div className="field-row">
            <div className="field">
              <label><MapPin size={13} /> Pickup / Origin</label>
              <input type="text" placeholder="e.g. Head Office, Harare" value={form.origin} onChange={e => set('origin', e.target.value)} />
            </div>
            <div className="field">
              <label><MapPin size={13} /> Destination</label>
              <input type="text" placeholder="e.g. Bulawayo Branch" value={form.destination} onChange={e => set('destination', e.target.value)} />
            </div>
          </div>

          <div className="field-row">
            <div className="field">
              <label><Calendar size={13} /> Requested Date</label>
              <input type="date" value={form.requested_date} min={new Date().toISOString().split('T')[0]} onChange={e => set('requested_date', e.target.value)} />
            </div>
            <div className="field">
              <label><Clock size={13} /> Requested Time</label>
              <input type="time" value={form.requested_time} onChange={e => set('requested_time', e.target.value)} />
            </div>
          </div>

          <div className="trms-form-section">Cargo Details</div>
          <div className="field">
            <label><Package size={13} /> Cargo Description</label>
            <input type="text" placeholder="What will be transported?" value={form.cargo_description} onChange={e => set('cargo_description', e.target.value)} />
          </div>
          <div className="field-row">
            <div className="field">
              <label>Weight (kg) — optional</label>
              <input type="number" placeholder="Approximate weight" value={form.cargo_weight_kg} onChange={e => set('cargo_weight_kg', e.target.value)} />
            </div>
            <div className="field">
              <label><Truck size={13} /> Required Truck Type</label>
              <select value={form.required_truck_class} onChange={e => set('required_truck_class', e.target.value)}>
                {TRUCK_CLASSES.map(t => <option key={t} value={t}>{t === 'any' ? 'Any truck' : t}</option>)}
              </select>
            </div>
          </div>

          <div className="trms-form-section">Return Trip</div>
          <div className="field checkbox-field">
            <label>
              <input type="checkbox" checked={form.return_required} onChange={e => set('return_required', e.target.checked)} />
              <RotateCcw size={13} /> Return trip required
            </label>
          </div>
          {form.return_required && (
            <div className="field">
              <label><Calendar size={13} /> Return Date</label>
              <input type="date" value={form.return_date} min={form.requested_date || new Date().toISOString().split('T')[0]} onChange={e => set('return_date', e.target.value)} />
            </div>
          )}

          {error && <p className="error-msg">{error}</p>}

          <button className="btn-primary trms-submit-btn" onClick={handleSubmit} disabled={loading}>
            {loading ? 'Submitting...' : 'Submit Request'}
          </button>
        </div>

        <div className="trms-map-side">
          <p className="map-label">Pin pickup & destination on the map</p>
          <BookingMap pickup={pickup} dropoff={dropoff} onPickup={setPickup} onDropoff={setDropoff} />
        </div>
      </div>
    </div>
  );
}
