import { useState } from 'react';
import { Routes, Route, Link, useLocation, Navigate } from 'react-router-dom';
import {
  Truck, ClipboardList, Users, Wrench, Bell, LogOut,
  LayoutDashboard, ChevronRight
} from 'lucide-react';
import { useTRMS } from '../../context/TRMSContext';
import api from '../../utils/api';
import TRMSLogin from './TRMSLogin';
import TRMSDashboard from './TRMSDashboard';
import TRMSRequests from './TRMSRequests';
import TRMSNewRequest from './TRMSNewRequest';
import TRMSRequestDetail from './TRMSRequestDetail';
import TRMSFleet from './TRMSFleet';
import TRMSDrivers from './TRMSDrivers';
import './TRMS.css';

const NAV = [
  { path: '/trms/dashboard', label: 'Dashboard',  icon: LayoutDashboard, roles: ['requester','supervisor','transport_manager','admin'] },
  { path: '/trms/requests',  label: 'Requests',   icon: ClipboardList,   roles: ['requester','supervisor','transport_manager','admin'] },
  { path: '/trms/fleet',     label: 'Fleet',      icon: Truck,           roles: ['supervisor','transport_manager','admin'] },
  { path: '/trms/drivers',   label: 'Drivers',    icon: Users,           roles: ['transport_manager','admin'] },
];

function TRMSSidebar() {
  const { user, logout, notifs } = useTRMS();
  const { pathname } = useLocation();

  const roleColor = { requester:'#3B82F6', supervisor:'#F59E0B', transport_manager:'#10B981', admin:'#8B5CF6' };

  return (
    <aside className="trms-sidebar">
      <div className="trms-sidebar-header">
        <Truck size={22} color="var(--gold)" />
        <div>
          <div className="trms-brand">TRMS</div>
          <div className="trms-brand-sub">Truck Request System</div>
        </div>
      </div>

      <div className="trms-user-badge">
        <div className="trms-user-name">{user?.name}</div>
        <div className="trms-user-role" style={{ color: roleColor[user?.role] }}>
          {user?.role?.replace('_', ' ')}
        </div>
        {user?.department && <div className="trms-user-dept">{user?.department}</div>}
      </div>

      <nav className="trms-nav">
        {NAV.filter(n => n.roles.includes(user?.role)).map(n => {
          const Icon = n.icon;
          const active = pathname.startsWith(n.path);
          return (
            <Link key={n.path} to={n.path} className={`trms-nav-item ${active ? 'active' : ''}`}>
              <Icon size={17} />
              <span>{n.label}</span>
              {n.path === '/trms/requests' && notifs.length > 0 && (
                <span className="trms-notif-dot">{notifs.length}</span>
              )}
              {active && <ChevronRight size={14} className="trms-nav-arrow" />}
            </Link>
          );
        })}
      </nav>

      <div className="trms-sidebar-footer">
        <Link to="/" className="trms-back-link">← Back to RidesZW</Link>
        <button className="trms-logout" onClick={logout}><LogOut size={14} /> Logout</button>
      </div>
    </aside>
  );
}

export default function TRMSPortal() {
  const { user } = useTRMS();
  if (!user) return <TRMSLogin />;

  return (
    <div className="trms-layout">
      <TRMSSidebar />
      <main className="trms-main">
        <Routes>
          <Route index element={<Navigate to="/trms/dashboard" replace />} />
          <Route path="dashboard"        element={<TRMSDashboard />} />
          <Route path="requests"         element={<TRMSRequests />} />
          <Route path="requests/new"     element={<TRMSNewRequest />} />
          <Route path="requests/:ref"    element={<TRMSRequestDetail />} />
          <Route path="fleet"            element={<TRMSFleet />} />
          <Route path="drivers"          element={<TRMSDrivers />} />
        </Routes>
      </main>
    </div>
  );
}
