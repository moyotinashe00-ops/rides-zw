import { useState, useEffect } from 'react';
import { Plus, User, Phone, CreditCard, Star, AlertCircle } from 'lucide-react';
import { useTRMS } from '../../context/TRMSContext';
import api from '../../utils/api';

const STATUS_COLORS = { available:'badge-confirmed', on_trip:'badge-in_transit', off_duty:'badge-pending', suspended:'badge-cancelled' };

export default function TRMSDrivers() {
  const { user }            = useTRMS();
  const [drivers, setDrivers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showAdd, setShowAdd] = useState(false);
  const [form, setForm]       = useState({ name:'', phone:'', email:'', license_number:'', license_expiry:'', notes:'' });
  const [error, setError]     = useState('');
  const [saving, setSaving]   = useState(false);

  const loadDrivers = async () => {
    try { const { data } = await api.get('/api/trms/drivers'); setDrivers(data); }
    catch (e) { console.error(e); }
    finally { setLoading(false); }
  };
  useEffect(() => { loadDrivers(); }, []);

  const addDriver = async () => {
    setError(''); setSaving(true);
    try {
      await api.post('/api/trms/drivers', form);
      setShowAdd(false);
      setForm({ name:'', phone:'', email:'', license_number:'', license_expiry:'', notes:'' });
      loadDrivers();
    } catch (e) { setError(e.response?.data?.error || 'Failed'); }
    finally { setSaving(false); }
  };

  const updateStatus = async (id, status) => {
    await api.patch(`/api/trms/drivers/${id}`, { status });
    loadDrivers();
  };

  const canEdit = ['transport_manager','admin'].includes(user?.role);

  const licenseExpiringSoon = (expiry) => {
    const days = Math.ceil((new Date(expiry) - new Date()) / 86400000);
    return days <= 30;
  };

  return (
    <div className="trms-page">
      <div className="trms-page-header">
        <div>
          <h1>Driver Management</h1>
          <p className="trms-page-sub">{drivers.length} driver(s) registered</p>
        </div>
        {canEdit && <button className="btn-primary" onClick={() => setShowAdd(true)}><Plus size={16} /> Register Driver</button>}
      </div>

      {/* Summary pills */}
      <div className="trms-fleet-summary">
        {['available','on_trip','off_duty','suspended'].map(s => (
          <div key={s} className={`fleet-summary-pill ${s === 'on_trip' ? 'assigned' : s}`}>
            <User size={14} /> {drivers.filter(d => d.status === s).length} {s.replace('_',' ')}
          </div>
        ))}
      </div>

      {loading ? <div className="trms-loading">Loading...</div> : (
        <div className="trms-table-wrapper">
          <table className="trms-table">
            <thead>
              <tr>
                <th>Driver</th>
                <th>Phone</th>
                <th>License No.</th>
                <th>License Expiry</th>
                <th>Trips</th>
                <th>Rating</th>
                <th>Status</th>
                {canEdit && <th>Action</th>}
              </tr>
            </thead>
            <tbody>
              {drivers.map(d => (
                <tr key={d.id}>
                  <td>
                    <div className="trms-requester-cell">
                      <strong>{d.name}</strong>
                      {d.email && <span>{d.email}</span>}
                    </div>
                  </td>
                  <td><span style={{display:'flex', alignItems:'center', gap:4}}><Phone size={12} /> {d.phone}</span></td>
                  <td><code className="trms-ref">{d.license_number}</code></td>
                  <td>
                    <span style={{color: licenseExpiringSoon(d.license_expiry) ? 'var(--danger)' : 'inherit', display:'flex', alignItems:'center', gap:4}}>
                      {licenseExpiringSoon(d.license_expiry) && <AlertCircle size={13} />}
                      {new Date(d.license_expiry).toLocaleDateString('en-ZW')}
                    </span>
                  </td>
                  <td>{d.trips_completed}</td>
                  <td>
                    {d.rating > 0
                      ? <span style={{display:'flex', alignItems:'center', gap:3}}><Star size={13} color="var(--gold)" fill="var(--gold)" /> {Number(d.rating).toFixed(1)}</span>
                      : <span style={{color:'var(--muted)'}}>New</span>
                    }
                  </td>
                  <td><span className={`badge ${STATUS_COLORS[d.status]}`}>{d.status.replace('_',' ')}</span></td>
                  {canEdit && (
                    <td>
                      <select value={d.status} onChange={e => updateStatus(d.id, e.target.value)} className="fleet-status-select">
                        <option value="available">Available</option>
                        <option value="on_trip">On Trip</option>
                        <option value="off_duty">Off Duty</option>
                        <option value="suspended">Suspended</option>
                      </select>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {/* Add driver modal */}
      {showAdd && (
        <div className="trms-modal-overlay" onClick={() => setShowAdd(false)}>
          <div className="trms-modal card" onClick={e => e.stopPropagation()}>
            <h3>Register New Driver</h3>
            <div className="field-row">
              <div className="field"><label><User size={13} /> Full Name</label><input placeholder="Driver's name" value={form.name} onChange={e => setForm(f => ({...f, name: e.target.value}))} /></div>
              <div className="field"><label><Phone size={13} /> Phone</label><input placeholder="+263 7X XXX XXXX" value={form.phone} onChange={e => setForm(f => ({...f, phone: e.target.value}))} /></div>
            </div>
            <div className="field"><label>Email (optional)</label><input type="email" value={form.email} onChange={e => setForm(f => ({...f, email: e.target.value}))} /></div>
            <div className="field-row">
              <div className="field"><label><CreditCard size={13} /> License Number</label><input placeholder="ZW-DL-XXXXXX" value={form.license_number} onChange={e => setForm(f => ({...f, license_number: e.target.value}))} /></div>
              <div className="field"><label>License Expiry</label><input type="date" value={form.license_expiry} onChange={e => setForm(f => ({...f, license_expiry: e.target.value}))} /></div>
            </div>
            <div className="field"><label>Notes</label><textarea rows={2} value={form.notes} onChange={e => setForm(f => ({...f, notes: e.target.value}))} /></div>
            {error && <p className="error-msg">{error}</p>}
            <div className="trms-modal-actions">
              <button className="btn-primary" onClick={addDriver} disabled={saving}>Register Driver</button>
              <button className="btn-outline" onClick={() => setShowAdd(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
