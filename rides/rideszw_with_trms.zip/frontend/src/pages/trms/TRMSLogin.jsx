import { useState } from 'react';
import { Truck, Mail, Lock } from 'lucide-react';
import { useTRMS } from '../../context/TRMSContext';
import api from '../../utils/api';
import './TRMS.css';

export default function TRMSLogin() {
  const { login } = useTRMS();
  const [form, setForm]     = useState({ email:'', password:'' });
  const [error, setError]   = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    setError(''); setLoading(true);
    try {
      const { data } = await api.post('/api/trms/auth/login', form);
      login(data);
    } catch (e) {
      setError(e.response?.data?.error || 'Login failed');
    } finally { setLoading(false); }
  };

  return (
    <div className="trms-login-page">
      <div className="trms-login-card">
        <div className="trms-login-logo">
          <Truck size={32} color="var(--gold)" />
          <div>
            <div className="trms-login-title">TRMS</div>
            <div className="trms-login-sub">Truck Request Management System</div>
          </div>
        </div>

        <h2>Sign In</h2>
        <p className="trms-login-hint">Use your organisation credentials to access TRMS</p>

        <div className="field">
          <label><Mail size={13} /> Email</label>
          <input type="email" placeholder="your@email.com" value={form.email}
            onChange={e => setForm(f => ({...f, email: e.target.value}))}
            onKeyDown={e => e.key === 'Enter' && handleLogin()} />
        </div>
        <div className="field">
          <label><Lock size={13} /> Password</label>
          <input type="password" value={form.password}
            onChange={e => setForm(f => ({...f, password: e.target.value}))}
            onKeyDown={e => e.key === 'Enter' && handleLogin()} />
        </div>

        {error && <p className="error-msg">{error}</p>}

        <button className="btn-primary trms-login-btn" onClick={handleLogin} disabled={loading}>
          {loading ? 'Signing in...' : 'Sign In'}
        </button>

        <div className="trms-demo-accounts">
          <p>Demo accounts (password: <strong>trms123</strong>)</p>
          <div className="demo-grid">
            {[
              { role:'Requester',         email:'requester@rideszw.co.zw' },
              { role:'Supervisor',        email:'supervisor@rideszw.co.zw' },
              { role:'Transport Manager', email:'manager@rideszw.co.zw' },
              { role:'Admin',             email:'trmsadmin@rideszw.co.zw' },
            ].map(d => (
              <button key={d.role} className="demo-btn"
                onClick={() => setForm({ email: d.email, password: 'trms123' })}>
                {d.role}
              </button>
            ))}
          </div>
        </div>

        <a href="/" className="trms-back">← Back to RidesZW</a>
      </div>
    </div>
  );
}
