import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import {
  ArrowLeft, ArrowRight, CheckCircle, XCircle, Truck,
  User, Calendar, Clock, Package, MapPin, AlertCircle,
  ThumbsUp, ThumbsDown, Play, Flag
} from 'lucide-react';
import { useTRMS } from '../../context/TRMSContext';
import api from '../../utils/api';

const STEP_ORDER = ['pending','supervisor_approved','assigned','in_transit','completed'];
const STEP_LABEL = ['Submitted','Sup. Approved','Assigned','In Transit','Completed'];

export default function TRMSRequestDetail() {
  const { ref }         = useParams();
  const navigate        = useNavigate();
  const { user }        = useTRMS();
  const [req, setReq]   = useState(null);
  const [loading, setLoading] = useState(true);
  const [error, setError]     = useState('');

  // approval form state
  const [comment, setComment]         = useState('');
  const [rejectReason, setRejectReason] = useState('');
  const [fleetId, setFleetId]         = useState('');
  const [driverId, setDriverId]       = useState('');
  const [fleet, setFleet]             = useState([]);
  const [drivers, setDrivers]         = useState([]);
  const [actionLoading, setActionLoading] = useState(false);
  const [actionError, setActionError]     = useState('');

  const load = async () => {
    try {
      const { data } = await api.get(`/api/trms/requests/${ref}`);
      setReq(data);
      // load available fleet/drivers for manager
      if (['transport_manager','admin'].includes(user?.role) && data.status === 'supervisor_approved') {
        const [f, d] = await Promise.all([
          api.get('/api/trms/fleet', { params: { status: 'available' } }),
          api.get('/api/trms/drivers', { params: { status: 'available' } }),
        ]);
        setFleet(f.data); setDrivers(d.data);
      }
    } catch { setError('Request not found'); }
    finally { setLoading(false); }
  };

  useEffect(() => { load(); }, [ref]);

  const action = async (endpoint, body = {}) => {
    setActionError(''); setActionLoading(true);
    try {
      await api.patch(`/api/trms/requests/${req.id}/${endpoint}`, body);
      await load();
    } catch (e) {
      setActionError(e.response?.data?.error || 'Action failed');
    } finally { setActionLoading(false); }
  };

  const stepIdx = STEP_ORDER.indexOf(req?.status);

  const statusColor = {
    pending:'badge-pending', supervisor_approved:'badge-in_transit',
    assigned:'badge-confirmed', in_transit:'badge-in_transit',
    completed:'badge-completed', rejected:'badge-cancelled', cancelled:'badge-cancelled',
  };

  if (loading) return <div className="trms-loading">Loading...</div>;
  if (error)   return <div className="trms-empty"><AlertCircle size={40} /><p>{error}</p></div>;

  return (
    <div className="trms-page">
      <div className="trms-detail-header">
        <button className="trms-back-btn" onClick={() => navigate('/trms/requests')}>
          <ArrowLeft size={16} /> Requests
        </button>
        <div className="trms-detail-title">
          <code className="trms-ref lg">{req.ref}</code>
          <span className={`badge ${statusColor[req.status]}`}>{req.status.replace(/_/g,' ')}</span>
        </div>
      </div>

      {/* Progress stepper */}
      {!['rejected','cancelled'].includes(req.status) && (
        <div className="trms-stepper">
          {STEP_ORDER.map((s, i) => (
            <div key={s} className={`trms-step ${i <= stepIdx ? 'done' : ''} ${i === stepIdx ? 'current' : ''}`}>
              <div className="trms-step-dot">
                {i < stepIdx ? <CheckCircle size={16} /> : <span>{i + 1}</span>}
              </div>
              <span>{STEP_LABEL[i]}</span>
              {i < STEP_ORDER.length - 1 && <div className="trms-step-line" />}
            </div>
          ))}
        </div>
      )}

      {['rejected','cancelled'].includes(req.status) && (
        <div className="trms-rejected-banner">
          <XCircle size={18} />
          <span>{req.status === 'rejected' ? `Rejected: ${req.rejection_reason}` : 'This request was cancelled.'}</span>
        </div>
      )}

      <div className="trms-detail-layout">
        {/* Left — request info */}
        <div className="trms-detail-main">

          <div className="card trms-info-card">
            <h3>Trip Details</h3>
            <div className="trms-info-grid">
              <div className="trms-info-item"><span><MapPin size={12} /> From</span><strong>{req.origin}</strong></div>
              <div className="trms-info-item"><span><MapPin size={12} /> To</span><strong>{req.destination}</strong></div>
              <div className="trms-info-item"><span><Calendar size={12} /> Date</span><strong>{new Date(req.requested_date).toLocaleDateString('en-ZW', { weekday:'long', day:'numeric', month:'long' })}</strong></div>
              <div className="trms-info-item"><span><Clock size={12} /> Time</span><strong>{req.requested_time}</strong></div>
              <div className="trms-info-item full"><span>Purpose</span><strong>{req.purpose}</strong></div>
              {req.cargo_description && <div className="trms-info-item full"><span><Package size={12} /> Cargo</span><strong>{req.cargo_description}{req.cargo_weight_kg ? ` — ${req.cargo_weight_kg}kg` : ''}</strong></div>}
              <div className="trms-info-item"><span><Truck size={12} /> Truck needed</span><strong>{req.required_truck_class === 'any' ? 'Any' : req.required_truck_class}</strong></div>
              {req.return_required && <div className="trms-info-item"><span>Return date</span><strong>{new Date(req.return_date).toLocaleDateString('en-ZW')}</strong></div>}
            </div>
          </div>

          {/* Requester info */}
          <div className="card trms-info-card">
            <h3>Requester</h3>
            <div className="trms-info-grid">
              <div className="trms-info-item"><span><User size={12} /> Name</span><strong>{req.requester_name}</strong></div>
              <div className="trms-info-item"><span>Department</span><strong>{req.department}</strong></div>
              <div className="trms-info-item"><span>Email</span><strong>{req.requester_email}</strong></div>
              <div className="trms-info-item"><span>Submitted</span><strong>{new Date(req.created_at).toLocaleString('en-ZW')}</strong></div>
            </div>
          </div>

          {/* Approval trail */}
          <div className="card trms-info-card">
            <h3>Approval Trail</h3>
            <div className="trms-approval-trail">
              <div className={`trms-trail-step ${req.supervisor_id ? 'done' : ''}`}>
                <div className="trail-dot">{req.supervisor_id ? <CheckCircle size={14} /> : <span>1</span>}</div>
                <div className="trail-info">
                  <strong>Supervisor Approval</strong>
                  {req.supervisor_id
                    ? <><span>{req.supervisor_name} — {new Date(req.supervisor_approved_at).toLocaleString('en-ZW')}</span>{req.supervisor_comment && <p className="trail-comment">"{req.supervisor_comment}"</p>}</>
                    : <span>Awaiting supervisor</span>
                  }
                </div>
              </div>
              <div className={`trms-trail-step ${req.manager_id ? 'done' : ''}`}>
                <div className="trail-dot">{req.manager_id ? <CheckCircle size={14} /> : <span>2</span>}</div>
                <div className="trail-info">
                  <strong>Transport Manager Approval</strong>
                  {req.manager_id
                    ? <><span>{req.manager_name} — {new Date(req.manager_approved_at).toLocaleString('en-ZW')}</span>{req.manager_comment && <p className="trail-comment">"{req.manager_comment}"</p>}</>
                    : <span>Awaiting manager</span>
                  }
                </div>
              </div>
            </div>
          </div>

          {/* Assignment info */}
          {req.assigned_fleet_id && (
            <div className="card trms-info-card">
              <h3>Assignment</h3>
              <div className="trms-info-grid">
                <div className="trms-info-item"><span><Truck size={12} /> Truck</span><strong>{req.truck_reg} — {req.make_model}</strong></div>
                <div className="trms-info-item"><span><User size={12} /> Driver</span><strong>{req.driver_name}</strong></div>
                <div className="trms-info-item"><span>Driver Phone</span><strong>{req.driver_phone}</strong></div>
                <div className="trms-info-item"><span>License</span><strong>{req.license_number}</strong></div>
                {req.assigned_at && <div className="trms-info-item"><span>Assigned at</span><strong>{new Date(req.assigned_at).toLocaleString('en-ZW')}</strong></div>}
                {req.actual_start && <div className="trms-info-item"><span>Trip started</span><strong>{new Date(req.actual_start).toLocaleString('en-ZW')}</strong></div>}
                {req.actual_end && <div className="trms-info-item"><span>Trip ended</span><strong>{new Date(req.actual_end).toLocaleString('en-ZW')}</strong></div>}
                {req.distance_km && <div className="trms-info-item"><span>Distance</span><strong>{req.distance_km} km</strong></div>}
              </div>
            </div>
          )}
        </div>

        {/* Right — action panel */}
        <div className="trms-detail-side">

          {/* Supervisor: approve/reject pending */}
          {user?.role === 'supervisor' && req.status === 'pending' && (
            <div className="card trms-action-card">
              <h3>Supervisor Review</h3>
              <div className="field">
                <label>Comment (optional)</label>
                <textarea rows={3} placeholder="Add a note..." value={comment} onChange={e => setComment(e.target.value)} />
              </div>
              {actionError && <p className="error-msg">{actionError}</p>}
              <button className="btn-primary trms-approve-btn" onClick={() => action('supervisor-approve', { comment })} disabled={actionLoading}>
                <ThumbsUp size={15} /> Approve
              </button>
              <div className="field" style={{marginTop:12}}>
                <label>Rejection reason (required to reject)</label>
                <textarea rows={2} placeholder="Why are you rejecting?" value={rejectReason} onChange={e => setRejectReason(e.target.value)} />
              </div>
              <button className="trms-reject-btn" onClick={() => action('reject', { reason: rejectReason })} disabled={actionLoading || !rejectReason}>
                <ThumbsDown size={15} /> Reject
              </button>
            </div>
          )}

          {/* Manager: assign truck + driver + approve */}
          {['transport_manager','admin'].includes(user?.role) && req.status === 'supervisor_approved' && (
            <div className="card trms-action-card">
              <h3>Manager Approval & Assignment</h3>
              <div className="field">
                <label><Truck size={13} /> Assign Truck</label>
                <select value={fleetId} onChange={e => setFleetId(e.target.value)}>
                  <option value="">Select available truck</option>
                  {fleet.map(f => (
                    <option key={f.id} value={f.id}>{f.registration} — {f.make_model} ({f.truck_class})</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label><User size={13} /> Assign Driver</label>
                <select value={driverId} onChange={e => setDriverId(e.target.value)}>
                  <option value="">Select available driver</option>
                  {drivers.map(d => (
                    <option key={d.id} value={d.id}>{d.name} — {d.license_number}</option>
                  ))}
                </select>
              </div>
              <div className="field">
                <label>Comment (optional)</label>
                <textarea rows={2} value={comment} onChange={e => setComment(e.target.value)} />
              </div>
              {actionError && <p className="error-msg">{actionError}</p>}
              <button className="btn-primary trms-approve-btn"
                onClick={() => action('manager-approve', { comment, fleet_id: fleetId, driver_id: driverId })}
                disabled={actionLoading || !fleetId || !driverId}>
                <ThumbsUp size={15} /> Approve & Assign
              </button>
              <button className="trms-reject-btn" style={{marginTop:8}} onClick={() => action('reject', { reason: rejectReason || 'Rejected by transport manager' })} disabled={actionLoading}>
                <ThumbsDown size={15} /> Reject
              </button>
            </div>
          )}

          {/* Admin/Manager: start/complete trip */}
          {['transport_manager','admin'].includes(user?.role) && req.status === 'assigned' && (
            <div className="card trms-action-card">
              <h3>Trip Control</h3>
              {actionError && <p className="error-msg">{actionError}</p>}
              <button className="btn-primary trms-approve-btn" onClick={() => action('start')} disabled={actionLoading}>
                <Play size={15} /> Start Trip
              </button>
            </div>
          )}
          {['transport_manager','admin'].includes(user?.role) && req.status === 'in_transit' && (
            <div className="card trms-action-card">
              <h3>Complete Trip</h3>
              <div className="field">
                <label>Distance covered (km)</label>
                <input type="number" placeholder="e.g. 439" value={comment} onChange={e => setComment(e.target.value)} />
              </div>
              {actionError && <p className="error-msg">{actionError}</p>}
              <button className="btn-primary trms-approve-btn" onClick={() => action('complete', { distance_km: comment })} disabled={actionLoading}>
                <Flag size={15} /> Mark as Completed
              </button>
            </div>
          )}

          {/* Requester: cancel */}
          {req.requester_id === user?.id && ['pending','supervisor_approved'].includes(req.status) && (
            <div className="card trms-action-card">
              <h3>Cancel Request</h3>
              <p style={{fontSize:13, color:'var(--muted)', marginBottom:12}}>You can cancel this request while it is still in the approval stage.</p>
              {actionError && <p className="error-msg">{actionError}</p>}
              <button className="trms-reject-btn" onClick={() => action('cancel')} disabled={actionLoading}>
                <XCircle size={15} /> Cancel Request
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
