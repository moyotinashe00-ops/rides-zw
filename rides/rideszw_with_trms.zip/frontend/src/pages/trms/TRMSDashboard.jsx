import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import {
  ClipboardList, Truck, Users, Clock, CheckCircle,
  XCircle, AlertCircle, ArrowRight, Plus, TrendingUp
} from 'lucide-react';
import { useTRMS } from '../../context/TRMSContext';
import api from '../../utils/api';

const statusColor = {
  pending:              'badge-pending',
  supervisor_approved:  'badge-in_transit',
  manager_approved:     'badge-in_transit',
  assigned:             'badge-confirmed',
  in_transit:           'badge-in_transit',
  completed:            'badge-completed',
  rejected:             'badge-cancelled',
  cancelled:            'badge-cancelled',
};

const statusLabel = {
  pending:             'Pending',
  supervisor_approved: 'Sup. Approved',
  manager_approved:    'Mgr Approved',
  assigned:            'Assigned',
  in_transit:          'In Transit',
  completed:           'Completed',
  rejected:            'Rejected',
  cancelled:           'Cancelled',
};

export default function TRMSDashboard() {
  const { user } = useTRMS();
  const [stats, setStats]     = useState(null);
  const [recent, setRecent]   = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const loadData = async () => {
      try {
        const [req] = await Promise.all([
          api.get('/api/trms/requests'),
        ]);
        setRecent(req.data.slice(0, 6));

        if (['admin','transport_manager','supervisor'].includes(user?.role)) {
          const { data } = await api.get('/api/trms/requests/stats/summary');
          setStats(data);
        }
      } catch (e) { console.error(e); }
      finally { setLoading(false); }
    };
    loadData();
  }, []);

  const greeting = () => {
    const h = new Date().getHours();
    if (h < 12) return 'Good morning';
    if (h < 17) return 'Good afternoon';
    return 'Good evening';
  };

  if (loading) return <div className="trms-loading">Loading dashboard...</div>;

  return (
    <div className="trms-page">
      <div className="trms-page-header">
        <div>
          <h1>{greeting()}, {user?.name?.split(' ')[0]}</h1>
          <p className="trms-page-sub">{user?.department} · {user?.role?.replace('_',' ')}</p>
        </div>
        {['requester','admin'].includes(user?.role) && (
          <Link to="/trms/requests/new" className="btn-primary">
            <Plus size={16} /> New Request
          </Link>
        )}
      </div>

      {/* Stats grid — managers and above */}
      {stats && (
        <div className="trms-stats-grid">
          <div className="trms-stat-card">
            <div className="trms-stat-icon pending-bg"><Clock size={20} /></div>
            <div><div className="trms-stat-value">{stats.pending}</div><div className="trms-stat-label">Pending</div></div>
          </div>
          <div className="trms-stat-card">
            <div className="trms-stat-icon approved-bg"><CheckCircle size={20} /></div>
            <div><div className="trms-stat-value">{stats.supervisor_approved}</div><div className="trms-stat-label">Awaiting Manager</div></div>
          </div>
          <div className="trms-stat-card">
            <div className="trms-stat-icon assigned-bg"><Truck size={20} /></div>
            <div><div className="trms-stat-value">{Number(stats.assigned) + Number(stats.in_transit)}</div><div className="trms-stat-label">Active Trips</div></div>
          </div>
          <div className="trms-stat-card">
            <div className="trms-stat-icon completed-bg"><TrendingUp size={20} /></div>
            <div><div className="trms-stat-value">{stats.completed}</div><div className="trms-stat-label">Completed</div></div>
          </div>
          <div className="trms-stat-card">
            <div className="trms-stat-icon fleet-bg"><Truck size={20} /></div>
            <div><div className="trms-stat-value">{stats.fleet_available}</div><div className="trms-stat-label">Fleet Available</div></div>
          </div>
          <div className="trms-stat-card">
            <div className="trms-stat-icon drivers-bg"><Users size={20} /></div>
            <div><div className="trms-stat-value">{stats.drivers_available}</div><div className="trms-stat-label">Drivers Available</div></div>
          </div>
        </div>
      )}

      {/* Action cards for supervisors/managers */}
      {user?.role === 'supervisor' && (
        <div className="trms-action-banner pending-action">
          <AlertCircle size={20} />
          <span>{stats?.pending || 0} request(s) awaiting your approval</span>
          <Link to="/trms/requests?status=pending" className="action-link">Review now <ArrowRight size={14} /></Link>
        </div>
      )}
      {user?.role === 'transport_manager' && (
        <div className="trms-action-banner approved-action">
          <AlertCircle size={20} />
          <span>{stats?.supervisor_approved || 0} request(s) awaiting your approval & truck assignment</span>
          <Link to="/trms/requests?status=supervisor_approved" className="action-link">Review now <ArrowRight size={14} /></Link>
        </div>
      )}

      {/* Recent requests */}
      <div className="trms-section">
        <div className="trms-section-header">
          <h2>Recent Requests</h2>
          <Link to="/trms/requests" className="trms-see-all">See all <ArrowRight size={14} /></Link>
        </div>
        {recent.length === 0 ? (
          <div className="trms-empty">
            <ClipboardList size={40} color="var(--muted)" />
            <p>No requests yet.</p>
            {user?.role === 'requester' && <Link to="/trms/requests/new" className="btn-primary"><Plus size={15} /> Create your first request</Link>}
          </div>
        ) : (
          <div className="trms-request-list">
            {recent.map(r => (
              <Link to={`/trms/requests/${r.ref}`} key={r.id} className="trms-request-row">
                <div className="trms-req-ref">{r.ref}</div>
                <div className="trms-req-route">
                  <strong>{r.origin}</strong>
                  <ArrowRight size={14} color="var(--muted)" />
                  <strong>{r.destination}</strong>
                </div>
                <div className="trms-req-purpose">{r.purpose}</div>
                <div className="trms-req-meta">
                  <span>{r.requester_name || 'You'}</span>
                  <span>{new Date(r.requested_date).toLocaleDateString('en-ZW', { day:'numeric', month:'short' })}</span>
                </div>
                <span className={`badge ${statusColor[r.status]}`}>{statusLabel[r.status]}</span>
              </Link>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
