import { useState, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { Plus, Search, ArrowRight, Filter } from 'lucide-react';
import { useTRMS } from '../../context/TRMSContext';
import api from '../../utils/api';

const STATUS_OPTIONS = [
  { value:'', label:'All Statuses' },
  { value:'pending',              label:'Pending' },
  { value:'supervisor_approved',  label:'Sup. Approved' },
  { value:'assigned',             label:'Assigned' },
  { value:'in_transit',           label:'In Transit' },
  { value:'completed',            label:'Completed' },
  { value:'rejected',             label:'Rejected' },
  { value:'cancelled',            label:'Cancelled' },
];

const statusColor = {
  pending:'badge-pending', supervisor_approved:'badge-in_transit',
  assigned:'badge-confirmed', in_transit:'badge-in_transit',
  completed:'badge-completed', rejected:'badge-cancelled', cancelled:'badge-cancelled',
};

export default function TRMSRequests() {
  const { user } = useTRMS();
  const [searchParams] = useSearchParams();
  const [requests, setRequests] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [filter, setFilter]     = useState({
    status: searchParams.get('status') || '',
    search: '',
    date: '',
  });

  const fetchRequests = async () => {
    setLoading(true);
    try {
      const params = {};
      if (filter.status) params.status = filter.status;
      if (filter.date)   params.date   = filter.date;
      const { data } = await api.get('/api/trms/requests', { params });
      const filtered = filter.search
        ? data.filter(r =>
            r.ref.toLowerCase().includes(filter.search.toLowerCase()) ||
            r.purpose.toLowerCase().includes(filter.search.toLowerCase()) ||
            r.origin.toLowerCase().includes(filter.search.toLowerCase()) ||
            r.destination.toLowerCase().includes(filter.search.toLowerCase()) ||
            (r.requester_name || '').toLowerCase().includes(filter.search.toLowerCase())
          )
        : data;
      setRequests(filtered);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };

  useEffect(() => { fetchRequests(); }, [filter.status, filter.date]);

  return (
    <div className="trms-page">
      <div className="trms-page-header">
        <div>
          <h1>Truck Requests</h1>
          <p className="trms-page-sub">{requests.length} request(s) found</p>
        </div>
        {['requester','admin'].includes(user?.role) && (
          <Link to="/trms/requests/new" className="btn-primary"><Plus size={16} /> New Request</Link>
        )}
      </div>

      {/* Filters */}
      <div className="trms-filters">
        <div className="trms-search-box">
          <Search size={15} color="var(--muted)" />
          <input
            placeholder="Search by ref, purpose, route..."
            value={filter.search}
            onChange={e => setFilter(f => ({...f, search: e.target.value}))}
            onKeyDown={e => e.key === 'Enter' && fetchRequests()}
          />
        </div>
        <select value={filter.status} onChange={e => setFilter(f => ({...f, status: e.target.value}))}>
          {STATUS_OPTIONS.map(o => <option key={o.value} value={o.value}>{o.label}</option>)}
        </select>
        <input type="date" value={filter.date} onChange={e => setFilter(f => ({...f, date: e.target.value}))} />
        <button className="btn-outline" onClick={fetchRequests}><Filter size={15} /> Filter</button>
      </div>

      {/* List */}
      {loading ? (
        <div className="trms-loading">Loading...</div>
      ) : requests.length === 0 ? (
        <div className="trms-empty">
          <Search size={40} color="var(--muted)" />
          <p>No requests found for these filters.</p>
        </div>
      ) : (
        <div className="trms-table-wrapper">
          <table className="trms-table">
            <thead>
              <tr>
                <th>Ref</th>
                <th>Requester</th>
                <th>Route</th>
                <th>Purpose</th>
                <th>Date</th>
                <th>Status</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {requests.map(r => (
                <tr key={r.id}>
                  <td><code className="trms-ref">{r.ref}</code></td>
                  <td>
                    <div className="trms-requester-cell">
                      <strong>{r.requester_name}</strong>
                      {r.department && <span>{r.department}</span>}
                    </div>
                  </td>
                  <td>
                    <div className="trms-route-cell">
                      <span>{r.origin}</span>
                      <ArrowRight size={12} color="var(--muted)" />
                      <span>{r.destination}</span>
                    </div>
                  </td>
                  <td className="trms-purpose-cell">{r.purpose}</td>
                  <td>{new Date(r.requested_date).toLocaleDateString('en-ZW', { day:'numeric', month:'short', year:'2-digit' })}</td>
                  <td><span className={`badge ${statusColor[r.status] || 'badge-pending'}`}>{r.status.replace(/_/g,' ')}</span></td>
                  <td>
                    <Link to={`/trms/requests/${r.ref}`} className="trms-view-btn">
                      View <ArrowRight size={13} />
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
