import { useState, useEffect } from 'react';
import { Plus, Truck, Wrench, CheckCircle, AlertCircle, XCircle } from 'lucide-react';
import { useTRMS } from '../../context/TRMSContext';
import api from '../../utils/api';

const TRUCK_CLASSES = ['pickup','1_3ton','5ton','10ton','flatbed','tanker','refrigerated'];
const STATUS_COLORS = { available:'badge-confirmed', assigned:'badge-in_transit', maintenance:'badge-pending', inactive:'badge-cancelled' };
const STATUS_ICONS  = { available: CheckCircle, assigned: Truck, maintenance: Wrench, inactive: XCircle };

export default function TRMSFleet() {
  const { user }          = useTRMS();
  const [fleet, setFleet] = useState([]);
  const [loading, setLoading]   = useState(true);
  const [showAdd, setShowAdd]   = useState(false);
  const [showMaint, setShowMaint] = useState(null); // fleet id
  const [form, setForm]   = useState({ registration:'', make_model:'', year:'', truck_class:'5ton', max_payload_kg:'', current_location:'', notes:'' });
  const [maint, setMaint] = useState({ type:'service', description:'', cost:'', date:'', next_due:'', done_by:'' });
  const [error, setError] = useState('');
  const [loading2, setLoading2] = useState(false);

  const loadFleet = async () => {
    try {
      const { data } = await api.get('/api/trms/fleet');
      setFleet(data);
    } catch (e) { console.error(e); }
    finally { setLoading(false); }
  };
  useEffect(() => { loadFleet(); }, []);

  const addFleet = async () => {
    setError(''); setLoading2(true);
    try {
      await api.post('/api/trms/fleet', form);
      setShowAdd(false);
      setForm({ registration:'', make_model:'', year:'', truck_class:'5ton', max_payload_kg:'', current_location:'', notes:'' });
      loadFleet();
    } catch (e) { setError(e.response?.data?.error || 'Failed to add truck'); }
    finally { setLoading2(false); }
  };

  const logMaintenance = async () => {
    setError(''); setLoading2(true);
    try {
      await api.post(`/api/trms/fleet/${showMaint}/maintenance`, maint);
      setShowMaint(null);
      setMaint({ type:'service', description:'', cost:'', date:'', next_due:'', done_by:'' });
      loadFleet();
    } catch (e) { setError(e.response?.data?.error || 'Failed to log maintenance'); }
    finally { setLoading2(false); }
  };

  const updateStatus = async (id, status) => {
    await api.patch(`/api/trms/fleet/${id}`, { status });
    loadFleet();
  };

  const canEdit = ['transport_manager','admin'].includes(user?.role);

  return (
    <div className="trms-page">
      <div className="trms-page-header">
        <div>
          <h1>Fleet Management</h1>
          <p className="trms-page-sub">{fleet.length} vehicle(s) registered</p>
        </div>
        {canEdit && <button className="btn-primary" onClick={() => setShowAdd(true)}><Plus size={16} /> Register Truck</button>}
      </div>

      {/* Summary pills */}
      <div className="trms-fleet-summary">
        {['available','assigned','maintenance','inactive'].map(s => {
          const Icon = STATUS_ICONS[s];
          const count = fleet.filter(f => f.status === s).length;
          return (
            <div key={s} className={`fleet-summary-pill ${s}`}>
              <Icon size={15} /> {count} {s}
            </div>
          );
        })}
      </div>

      {loading ? <div className="trms-loading">Loading...</div> : (
        <div className="trms-fleet-grid">
          {fleet.map(f => {
            const daysToService = f.next_service_date
              ? Math.ceil((new Date(f.next_service_date) - new Date()) / 86400000)
              : null;
            return (
              <div key={f.id} className="trms-fleet-card card">
                <div className="fleet-card-header">
                  <div>
                    <div className="fleet-reg">{f.registration}</div>
                    <div className="fleet-model">{f.make_model} {f.year || ''}</div>
                  </div>
                  <span className={`badge ${STATUS_COLORS[f.status]}`}>{f.status}</span>
                </div>
                <div className="fleet-details">
                  <span className="fleet-class">{f.truck_class}</span>
                  {f.max_payload_kg && <span>{f.max_payload_kg.toLocaleString()} kg</span>}
                  {f.current_location && <span>{f.current_location}</span>}
                </div>
                {daysToService !== null && (
                  <div className={`fleet-service-due ${daysToService <= 7 ? 'urgent' : ''}`}>
                    <Wrench size={12} />
                    {daysToService <= 0
                      ? 'Service overdue!'
                      : `Service due in ${daysToService} day(s)`
                    }
                  </div>
                )}
                {canEdit && (
                  <div className="fleet-actions">
                    <select value={f.status} onChange={e => updateStatus(f.id, e.target.value)} className="fleet-status-select">
                      <option value="available">Available</option>
                      <option value="assigned">Assigned</option>
                      <option value="maintenance">Maintenance</option>
                      <option value="inactive">Inactive</option>
                    </select>
                    <button className="trms-maint-btn" onClick={() => setShowMaint(f.id)}>
                      <Wrench size={13} /> Log Service
                    </button>
                  </div>
                )}
              </div>
            );
          })}
        </div>
      )}

      {/* Add fleet modal */}
      {showAdd && (
        <div className="trms-modal-overlay" onClick={() => setShowAdd(false)}>
          <div className="trms-modal card" onClick={e => e.stopPropagation()}>
            <h3>Register New Truck</h3>
            <div className="field-row">
              <div className="field"><label>Registration</label><input placeholder="e.g. ABD 1234" value={form.registration} onChange={e => setForm(f => ({...f, registration: e.target.value}))} /></div>
              <div className="field"><label>Make & Model</label><input placeholder="e.g. Isuzu NQR" value={form.make_model} onChange={e => setForm(f => ({...f, make_model: e.target.value}))} /></div>
            </div>
            <div className="field-row">
              <div className="field"><label>Year</label><input type="number" placeholder="2020" value={form.year} onChange={e => setForm(f => ({...f, year: e.target.value}))} /></div>
              <div className="field"><label>Truck Class</label>
                <select value={form.truck_class} onChange={e => setForm(f => ({...f, truck_class: e.target.value}))}>
                  {TRUCK_CLASSES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>
            <div className="field-row">
              <div className="field"><label>Max Payload (kg)</label><input type="number" value={form.max_payload_kg} onChange={e => setForm(f => ({...f, max_payload_kg: e.target.value}))} /></div>
              <div className="field"><label>Current Location</label><input placeholder="e.g. Harare Depot" value={form.current_location} onChange={e => setForm(f => ({...f, current_location: e.target.value}))} /></div>
            </div>
            <div className="field"><label>Notes</label><textarea rows={2} value={form.notes} onChange={e => setForm(f => ({...f, notes: e.target.value}))} /></div>
            {error && <p className="error-msg">{error}</p>}
            <div className="trms-modal-actions">
              <button className="btn-primary" onClick={addFleet} disabled={loading2}>Register</button>
              <button className="btn-outline" onClick={() => setShowAdd(false)}>Cancel</button>
            </div>
          </div>
        </div>
      )}

      {/* Maintenance modal */}
      {showMaint && (
        <div className="trms-modal-overlay" onClick={() => setShowMaint(null)}>
          <div className="trms-modal card" onClick={e => e.stopPropagation()}>
            <h3>Log Maintenance — {fleet.find(f => f.id === showMaint)?.registration}</h3>
            <div className="field-row">
              <div className="field"><label>Type</label>
                <select value={maint.type} onChange={e => setMaint(m => ({...m, type: e.target.value}))}>
                  {['service','repair','inspection','tyre','other'].map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
              <div className="field"><label>Date</label><input type="date" value={maint.date} onChange={e => setMaint(m => ({...m, date: e.target.value}))} /></div>
            </div>
            <div className="field"><label>Description</label><textarea rows={2} value={maint.description} onChange={e => setMaint(m => ({...m, description: e.target.value}))} /></div>
            <div className="field-row">
              <div className="field"><label>Cost (USD)</label><input type="number" value={maint.cost} onChange={e => setMaint(m => ({...m, cost: e.target.value}))} /></div>
              <div className="field"><label>Next Service Due</label><input type="date" value={maint.next_due} onChange={e => setMaint(m => ({...m, next_due: e.target.value}))} /></div>
            </div>
            <div className="field"><label>Done by</label><input placeholder="Workshop/mechanic name" value={maint.done_by} onChange={e => setMaint(m => ({...m, done_by: e.target.value}))} /></div>
            {error && <p className="error-msg">{error}</p>}
            <div className="trms-modal-actions">
              <button className="btn-primary" onClick={logMaintenance} disabled={loading2}>Save</button>
              <button className="btn-outline" onClick={() => setShowMaint(null)}>Cancel</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
