import { useState, useEffect } from 'react';
import { LogOut, Search, Users, Package, Truck, Clock, CheckCircle, XCircle, BarChart2 } from 'lucide-react';
import api from '../utils/api';
import './AdminPage.css';

export default function AdminPage() {
  const [token, setToken]       = useState(localStorage.getItem('rzw_token'));
  const [creds, setCreds]       = useState({ email:'', password:'' });
  const [loginErr, setLoginErr] = useState('');
  const [bookings, setBookings] = useState([]);
  const [stats, setStats]       = useState(null);
  const [filter, setFilter]     = useState({ type:'', status:'', search:'' });
  const [loading, setLoading]   = useState(false);

  const login = async () => {
    setLoginErr('');
    try {
      const { data } = await api.post('/auth/login', creds);
      localStorage.setItem('rzw_token', data.token);
      setToken(data.token);
    } catch (e) { setLoginErr(e.response?.data?.error || 'Login failed'); }
  };

  const logout = () => { localStorage.removeItem('rzw_token'); setToken(null); };

  const load = async () => {
    setLoading(true);
    try {
      const params = {};
      if (filter.type)   params.type   = filter.type;
      if (filter.status) params.status = filter.status;
      if (filter.search) params.search = filter.search;
      const [b, s] = await Promise.all([
        api.get('/bookings', { params }),
        api.get('/bookings/stats/summary'),
      ]);
      setBookings(b.data);
      setStats(s.data);
    } catch { logout(); }
    finally { setLoading(false); }
  };

  useEffect(() => { if (token) load(); }, [token, filter]);

  const updateStatus = async (id, status) => {
    await api.patch(`/bookings/${id}/status`, { status });
    load();
  };

  if (!token) return (
    <div className="admin-login">
      <div className="login-card card">
        <div className="login-logo"><span>Rides</span><span className="gold">ZW</span></div>
        <h2>Admin Login</h2>
        <div className="field"><label>Email</label><input type="email" value={creds.email} onChange={e => setCreds(c => ({...c, email:e.target.value}))} /></div>
        <div className="field"><label>Password</label><input type="password" value={creds.password} onChange={e => setCreds(c => ({...c, password:e.target.value}))} onKeyDown={e => e.key === 'Enter' && login()} /></div>
        {loginErr && <p className="error-msg">{loginErr}</p>}
        <button className="btn-primary" onClick={login}>Login</button>
      </div>
    </div>
  );

  return (
    <div className="admin-page">
      <div className="admin-topbar">
        <span className="admin-brand">RidesZW <span className="muted">Admin</span></span>
        <button className="btn-outline" onClick={logout}><LogOut size={14} /> Logout</button>
      </div>

      {stats && (
        <div className="stats-grid">
          <div className="stat-card"><span><BarChart2 size={14} /> Total</span><strong>{stats.total}</strong></div>
          <div className="stat-card"><span><Users size={14} /> Passengers</span><strong>{stats.passengers}</strong></div>
          <div className="stat-card"><span><Package size={14} /> Cargo</span><strong>{stats.cargo}</strong></div>
          <div className="stat-card"><span><Clock size={14} /> Pending</span><strong className="warn">{stats.pending}</strong></div>
          <div className="stat-card"><span><CheckCircle size={14} /> Confirmed</span><strong className="ok">{stats.confirmed}</strong></div>
          <div className="stat-card"><span><BarChart2 size={14} /> Revenue</span><strong className="ok">${Number(stats.revenue).toFixed(2)}</strong></div>
        </div>
      )}

      <div className="admin-filters">
        <input placeholder="Search name, phone, ref…" value={filter.search} onChange={e => setFilter(f => ({...f, search:e.target.value}))} />
        <select value={filter.type} onChange={e => setFilter(f => ({...f, type:e.target.value}))}>
          <option value="">All Types</option>
          <option value="passenger">Passenger</option>
          <option value="cargo">Cargo</option>
        </select>
        <select value={filter.status} onChange={e => setFilter(f => ({...f, status:e.target.value}))}>
          <option value="">All Statuses</option>
          <option value="pending">Pending</option>
          <option value="confirmed">Confirmed</option>
          <option value="in_transit">In Transit</option>
          <option value="completed">Completed</option>
          <option value="cancelled">Cancelled</option>
        </select>
      </div>

      {loading ? <p className="loading-msg">Loading...</p> : (
        <div className="table-wrapper">
          <table>
            <thead>
              <tr><th>Ref</th><th>Type</th><th>Route</th><th>Date</th><th>Name</th><th>Phone</th><th>Amount</th><th>Status</th><th>Action</th></tr>
            </thead>
            <tbody>
              {bookings.length === 0 && (
                <tr><td colSpan={9} style={{textAlign:'center', color:'var(--muted)', padding:'32px'}}>No bookings found</td></tr>
              )}
              {bookings.map(b => (
                <tr key={b.id}>
                  <td><code>{b.ref}</code></td>
                  <td><span className={`tag-${b.booking_type}`}>{b.booking_type}</span></td>
                  <td>{b.origin} → {b.destination}</td>
                  <td>{new Date(b.travel_date).toLocaleDateString('en-ZW')}</td>
                  <td>{b.passenger_name || b.sender_name}</td>
                  <td>{b.passenger_phone || b.sender_phone}</td>
                  <td>${b.amount}</td>
                  <td><span className={`badge badge-${b.status}`}>{b.status.replace('_',' ')}</span></td>
                  <td>
                    <select value={b.status} onChange={e => updateStatus(b.id, e.target.value)} className="status-select">
                      <option value="pending">Pending</option>
                      <option value="confirmed">Confirmed</option>
                      <option value="in_transit">In Transit</option>
                      <option value="completed">Completed</option>
                      <option value="cancelled">Cancelled</option>
                    </select>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
