import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Truck, Phone, Lock, User, Building2, Mail } from 'lucide-react';
import api from '../utils/api';
import './LoadboardPage.css';

export default function DriverAuth({ mode = 'login' }) {
  const navigate = useNavigate();
  const [form, setForm]     = useState({ name:'', phone:'', email:'', password:'', company_name:'' });
  const [error, setError]   = useState('');
  const [loading, setLoading] = useState(false);
  const set = (k,v) => setForm(f => ({...f, [k]:v}));
  const isLogin = mode === 'login';

  const handleSubmit = async () => {
    setError(''); setLoading(true);
    try {
      if (isLogin) {
        const { data } = await api.post('/truck-owners/login', { phone: form.phone, password: form.password });
        localStorage.setItem('rzw_owner', JSON.stringify({ ...data }));
        navigate('/loadboard');
      } else {
        await api.post('/truck-owners/register', form);
        navigate('/driver/login');
      }
    } catch (e) {
      setError(e.response?.data?.error || (isLogin ? 'Login failed' : 'Registration failed'));
    } finally { setLoading(false); }
  };

  return (
    <div className="driver-auth-page">
      <div className="driver-auth-card card">
        <div className="auth-logo"><Truck size={22} /> Truck Drive</div>
        <h2>{isLogin ? 'Driver Login' : 'Register as Driver'}</h2>
        <p className="auth-sub">{isLogin ? 'Sign in to bid on available loads' : 'Create your driver account to access the loadboard'}</p>

        {!isLogin && (<>
          <div className="field"><label><User size={13} /> Full Name</label><input type="text" placeholder="Your name" value={form.name} onChange={e => set('name', e.target.value)} /></div>
          <div className="field"><label><Building2 size={13} /> Company Name (optional)</label><input type="text" placeholder="Haulage company" value={form.company_name} onChange={e => set('company_name', e.target.value)} /></div>
          <div className="field"><label><Mail size={13} /> Email (optional)</label><input type="email" value={form.email} onChange={e => set('email', e.target.value)} /></div>
        </>)}

        <div className="field"><label><Phone size={13} /> Phone Number</label><input type="tel" placeholder="+263 7X XXX XXXX" value={form.phone} onChange={e => set('phone', e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSubmit()} /></div>
        <div className="field"><label><Lock size={13} /> Password</label><input type="password" value={form.password} onChange={e => set('password', e.target.value)} onKeyDown={e => e.key === 'Enter' && handleSubmit()} /></div>

        {error && <p className="error-msg">{error}</p>}
        <button className="btn-primary" onClick={handleSubmit} disabled={loading}>
          {loading ? '...' : isLogin ? 'Login' : 'Create Account'}
        </button>
        <p className="auth-switch">
          {isLogin
            ? <>No account? <a href="/driver/register">Register here</a></>
            : <>Already have an account? <a href="/driver/login">Login</a></>
          }
        </p>
      </div>
    </div>
  );
}
